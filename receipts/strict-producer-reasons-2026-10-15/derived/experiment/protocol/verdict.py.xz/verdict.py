#!/usr/bin/env python3
"""protocol reducer: every mandatory check, every report-only measurement, and the verdict order.

Python 3.9, standard library plus phase2/observers/obs.py. It reads recorded cells only; it never runs the analyzer.

  verdict.py campfire --cache-root CACHE --native DIR [--label ARM=LABEL ...] [--out FILE]
  verdict.py general  --cache-root CACHE [--label ARM=LABEL ...] [--out FILE]

A check is pass, fail or unavailable. Campfire verdict: INCONCLUSIVE if the pre-gate fails or any mandatory check is
unavailable; else KILLED if any mandatory check fails; else CONFIRMED. Report-only records never change the verdict.
"""
import argparse
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
F = HERE.parents[2]
sys.path.insert(0, str(F / "phase2/observers"))
import obs  # noqa: E402

S = ("unset", "1", "2", "repeat")
V1 = [s + "-v1-a1" for s in S]
V0 = [s + "-v0-a0" for s in S]
XA = [s + "-v0-a1" for s in S]
ARMS = ("S1", "S", "K", "SK")
EVIDENCE_KINDS = ("Gradual", "Unresolved", "LegacyAmbiguousVar")
URL = json.loads((HERE / "url_identities.json").read_text())
URL_BITS = {"C": {"unset": 6, "1": 2, "2": 6, "repeat": 6}, "S1": dict.fromkeys(S, 2)}


def rec(name, scope, status, detail=None, mandatory=True):
    return {"check": name, "scope": scope, "status": status, "mandatory": mandatory, "detail": detail}


FALLBACK = None  # set by --fallback-root: <root>/<label>/<app>/<setting>/{stderr.log,census.jsonl,exit}
APPS = json.loads((F / "phase2/observers/apps.json").read_text())


def records(cache, label):
    if FALLBACK is not None:
        out = {}
        for d in sorted((FALLBACK / label).glob("*/*")) if (FALLBACK / label).is_dir() else []:
            app, setting = d.parent.name, d.name
            try:
                code = int((d / "exit").read_text().strip())
                observations = obs.reduce_outputs(d, (F / APPS[app]["path"]).resolve(), code)
                out[app + "/" + setting] = {"valid": code in (0, 1), "directory": str(d), "observations": observations}
            except (OSError, ValueError, KeyError) as error:
                out[app + "/" + setting] = {"valid": False, "directory": str(d), "error": str(error)}
        return out or None
    try:
        return obs.label_records(obs.load_label(cache, label))
    except (OSError, ValueError, KeyError, TypeError, AttributeError):
        return None


def claim_checks(cache, label, spec, against=None, mandatory=True):
    out = []
    recs = records(cache, label)
    for claim in json.loads(Path(spec).read_text())["claims"]:
        claim = dict(claim)
        if claim.get("against"):
            claim["against"] = against or claim["against"]
        other = records(cache, claim["against"]) if claim.get("against") else None
        if recs is None or (claim.get("against") and other is None):
            out.append(rec(claim["name"], label, "unavailable", "label missing", mandatory))
            continue
        try:
            verdicts = obs.check_claim(claim, recs, other)
        except (OSError, ValueError, KeyError, TypeError, AttributeError) as error:
            out.append(rec(claim["name"], label, "unavailable", str(error), mandatory))
            continue
        for v in verdicts:
            unavailable = not v["passed"] and re.search(r"missing|invalid|unavailable", v.get("reason", ""))
            status = "pass" if v["passed"] else ("unavailable" if unavailable else "fail")
            out.append(rec(claim["name"], v["setting"], status,
                           {k: v[k] for k in ("reason", "changed_keys", "observed_delta") if k in v}, mandatory))
    return out


def cell(recs, app, setting):
    r = (recs or {}).get(app + "/" + setting)
    return r if r is not None and r.get("valid") else None


def url_bits(cache, label, arm, expect, mandatory, app="campfire"):
    recs, out = records(cache, label), []
    keys = [obs.canonical(i) for i in URL["identities"]]
    for s in S:
        r = cell(recs, app, s + "-v0-a0")
        rows = obs.observed(r, "reason_rows") if r else None
        if rows is None:
            out.append(rec("url-bits", label + "/" + s, "unavailable", None, mandatory))
            continue
        got = [rows.get(k) for k in keys]
        ok = all(g is not None and g["untyped_kinds"] == expect[s] and g["type_hash"] == URL["type_hash"] for g in got)
        out.append(rec("url-bits", label + "/" + s, "pass" if ok else "fail",
                       {"expected": expect[s], "observed": [g and g["untyped_kinds"] for g in got]}, mandatory))
    return out


LOOPS = ("production", "views_and_tests", "absorb")
DIGESTS = ("attributes", "block_values", "constants", "controller_bindings", "controller_cache",
           "copies", "ir", "params", "returns", "side_table")


def number(n):
    return type(n) is int and n >= 0


def report_json(r):
    try:
        report = json.loads((Path(r["directory"]) / "report.json").read_text())
        return report if isinstance(report, dict) else None
    except (OSError, ValueError, TypeError, KeyError):
        return None


def counters(report):
    try:
        w = report["worklist"]
        w = w.get("engine", w)
        result = {k: w[k] for k in ("cap_hits", "frozen_units", "budget_exhausted")}
        result["fold_budget_cuts"] = report["fold"]["expansion"]["budget_cuts"]
        return result if all(number(n) for n in result.values()) else None
    except (KeyError, TypeError, AttributeError):
        return None


def movement(observations):
    entries = observations.get("verify")
    if not isinstance(entries, list) or not entries:
        return None
    seen, total = set(), 0
    for entry in entries:
        if not isinstance(entry, dict) or entry.get("loop") not in LOOPS:
            return None
        moved = entry.get("moved")
        if (not isinstance(moved, dict) or not all(k in moved for k in DIGESTS)
                or not all(number(n) for n in moved.values())):
            return None
        seen.add(entry["loop"])
        total += sum(moved.values())
    return total if seen == set(LOOPS) else None


def evidence(observations):
    laws = observations.get("law_violation_counts")
    if not isinstance(laws, dict):
        return None
    entries = [value for key, value in laws.items() if key.startswith("producer_evidence_")]
    if not entries:
        return None
    total = 0
    for entry in entries:
        if not isinstance(entry, dict):
            return None
        kinds = entry.get("parameter_losses_by_kind")
        if not isinstance(kinds, dict) or not all(number(n) for n in kinds.values()):
            return None
        total += sum(n for k, n in kinds.items() if k in EVIDENCE_KINDS)
    return total


def invariants(cache, label, control, settings, mandatory=True, app="campfire", absolute=True,
               control_gate=False):
    """C pre-gate is absolute. Arm caps/loops stay relative; missing evidence outranks failures.

    Generalization retains both detail lists and applies its declared fail-before-unavailable priority.
    """
    recs, crecs, out = records(cache, label), records(cache, control), []
    for name in settings:
        scope, r, c = label + "/" + app + "/" + name, cell(recs, app, name), cell(crecs, app, name)
        if r is None or c is None:
            out.append(rec("invariants", scope, "unavailable", "missing or invalid cell", mandatory))
            continue
        problems, unavailable = [], []
        ro, co = r.get("observations"), c.get("observations")
        if not isinstance(ro, dict) or not isinstance(co, dict):
            out.append(rec("invariants", scope, "unavailable", "invalid observations", mandatory))
            continue
        if "-v1-" in name:
            mine, theirs = movement(ro), movement(co)
            if mine is None or theirs is None:
                unavailable.append("verify")
            elif mine > (0 if absolute else theirs):
                problems.append("verify movement")
        loops, cloops = ro.get("loops"), co.get("loops")
        for k in LOOPS:
            mine = loops.get(k) if isinstance(loops, dict) else None
            theirs = cloops.get(k) if isinstance(cloops, dict) else None
            if (not isinstance(mine, dict) or not isinstance(theirs, dict)
                    or not isinstance(mine.get("end"), str) or not mine["end"]
                    or not isinstance(theirs.get("end"), str) or not theirs["end"]):
                unavailable.append("loop " + k)
            elif (control_gate or theirs["end"] == "settled") and mine["end"] != "settled":
                problems.append("loop " + k + " not settled")
        a, b = counters(report_json(r)), counters(report_json(c))
        if a is None or b is None:
            unavailable.append("worklist/fold counters")
        else:
            problems += [k for k in a if a[k] > (0 if control_gate else b[k])]
        if name.endswith("-a1"):
            mine, theirs = evidence(ro), evidence(co)
            if mine is None or theirs is None:
                unavailable.append("law counts")
            elif mine > (0 if absolute else theirs):
                problems.append("evidence-kind origin losses " + str(mine))
        pend = []
        for ob in (ro, co):
            try:
                n = ob["reason_census"]["untyped_by_provenance"]["pending"]
                pend.append(n if number(n) else None)
            except (KeyError, TypeError):
                pend.append(None)
        if None in pend:
            unavailable.append("pending census")
        elif pend[0] > (0 if absolute else pend[1]):
            problems.append("pending census above limit")
        status = "unavailable" if unavailable else ("fail" if problems else "pass")
        out.append(rec("invariants", scope, status, {"problems": problems, "unavailable": unavailable}, mandatory))
    return out


def tagged(log, ex, tag):
    """One JSON object after a tag, optionally prefixed by Cargo's test-name output."""
    try:
        prefix = r"(?:test [^\n]+ \.\.\. )?"
        matches = [m.group(1) for line in log.read_text(errors="replace").splitlines()
                   for m in [re.fullmatch(prefix + re.escape(tag) + r" (.*)", line)] if m]
        if len(matches) != 1:
            raise ValueError("expected exactly one " + tag + " object")
        value, code = json.loads(matches[0]), int(ex.read_text().strip())
        if not isinstance(value, dict):
            raise ValueError("tagged JSON must be an object")
        return value, code, None
    except (OSError, ValueError, TypeError) as error:
        return None, None, str(error)


def native(directory):
    """H5g: provenance-STRICT per flag process, and the law census under XFER=0/1."""
    out, d = [], Path(directory)
    for f in ("000", "100", "010", "110", "001", "111"):
        stubs, xfer, cong = (int(x) for x in f)
        log, ex = d / ("harness-" + f + ".log"), d / ("harness-" + f + ".exit")
        got, code, error = tagged(log, ex, "provenance-STRICT")
        if error:
            out.append(rec("H5g-harness", f, "unavailable", error))
            continue
        required = {"flags": ("stubs", "xfer", "congruent"),
                    "strictness": ("p1", "p2", "p3", "p4", "p5", "p6", "p7b"),
                    "deferred_var": ("p7",), "identity": ("p8", "p9"),
                    "equality": ("p10_distinguishes",)}
        if any(not isinstance(got.get(k), dict) or not all(n in got[k] for n in names)
               for k, names in required.items()):
            out.append(rec("H5g-harness", f, "unavailable", "missing harness fields"))
            continue
        if (any(not number(got[k][n]) for k in ("flags", "strictness", "deferred_var", "identity")
                for n in required[k]) or type(got["equality"]["p10_distinguishes"]) is not bool):
            out.append(rec("H5g-harness", f, "unavailable", "invalid harness fields"))
            continue
        if code != 0:
            out.append(rec("H5g-harness", f, "fail", "test process exited " + str(code)))
            continue
        want = {"flags": {"stubs": stubs, "xfer": xfer, "congruent": cong}, "strictness": dict.fromkeys(("p1", "p2", "p3", "p4", "p5", "p6", "p7b"), 0 if xfer else 1),
                "deferred_var": {"p7": 1},
                "identity": {"p8": 0 if xfer else 1, "p9": 0 if (stubs or xfer) else 1},
                "equality": {"p10_distinguishes": bool(cong)}}
        got_body = {k: got.get(k) for k in want}
        out.append(rec("H5g-harness", f, "pass" if got_body == want else "fail", {"observed": got_body, "expected": want}))
    for x in ("0", "1"):
        for test, tag in (("storage_extended_laws", "STORAGE-EXTENDED "), ("provenance_lineage_factorial", "PENDING-FACTORIAL ")):
            log, ex = d / ("laws-x" + x + "-" + test + ".log"), d / ("laws-x" + x + "-" + test + ".exit")
            got, code, error = tagged(log, ex, tag.rstrip())
            if error:
                out.append(rec("H5g-laws", x + "/" + test, "unavailable", error))
                continue
            if (not isinstance(got.get("counts"), dict) or type(got.get("seed_ok")) is not bool
                    or type(got.get("no_early_never")) is not bool):
                out.append(rec("H5g-laws", x + "/" + test, "unavailable", "missing/invalid law fields"))
                continue
            ok = code == 0 and got["counts"] == {} and got["seed_ok"] and got["no_early_never"]
            out.append(rec("H5g-laws", x + "/" + test, "pass" if ok else "fail", got))
    return out


def classify(cache, label, arm, app="campfire"):
    """H5d (report-only): each V0 delta row is url, stale-P candidate (equal type hash, bits {2, 4}) or other."""
    recs, out, url = records(cache, label), [], {obs.canonical(i) for i in URL["identities"]}
    base = cell(recs, app, "unset-v0-a0")
    for s in S[1:]:
        r = cell(recs, app, s + "-v0-a0")
        if base is None or r is None:
            out.append(rec("H5d-classes", label + "/" + s, "unavailable", None, False))
            continue
        delta = obs.reason_delta(obs.observed(base, "reason_rows"), obs.observed(r, "reason_rows"))
        classes = {"url": 0, "stale_p_candidate": 0, "other": 0, "missing": len(delta["left_only"]) + len(delta["right_only"])}
        for c in delta["changes"]:
            if obs.canonical(c["identity"]) in url:
                classes["url"] += 1
            elif (c["left"]["type_hash"] == c["right"]["type_hash"]
                  and {c["left"]["untyped_kinds"], c["right"]["untyped_kinds"]} == {2, 4}):
                classes["stale_p_candidate"] += 1
            else:
                classes["other"] += 1
        predicted = not any(classes.values())
        out.append(rec("H5d-classes", label + "/" + s, "pass" if predicted else "fail", classes, False))
    return out


def decide(checks):
    gate = [c for c in checks if c["check"].startswith("PG") or c["check"] in ("pregate-url-bits", "pregate-invariants")]
    mand = [c for c in checks if c["mandatory"]]
    if any(c["status"] != "pass" for c in gate):
        return "INCONCLUSIVE (pre-gate)"
    if any(c["status"] == "unavailable" for c in mand):
        return "INCONCLUSIVE (unavailable mandatory evidence)"
    if any(c["status"] == "fail" for c in mand):
        return "KILLED"
    return "CONFIRMED"


def campfire(args, labels):
    cache, claims = args.cache_root.resolve(), HERE / "claims"
    checks = claim_checks(cache, labels["C"], claims / "pregate-C.json")
    checks += [dict(c, check="pregate-url-bits") for c in url_bits(cache, labels["C"], "C", URL_BITS["C"], True)]
    checks += [dict(c, check="pregate-invariants") for c in invariants(cache, labels["C"], labels["C"], V0 + V1 + XA, control_gate=True)]
    checks += native(args.native)
    for arm in ARMS:
        checks += claim_checks(cache, labels[arm], claims / ("arm-" + arm + ".json"), against=labels["C"])
        checks += invariants(cache, labels[arm], labels["C"], V0 + V1 + XA)
    checks += [dict(c, check="H5a-url-bits") for c in url_bits(cache, labels["S1"], "S1", URL_BITS["S1"], True)]
    checks += [dict(c, check="H5c-url-bits") for c in url_bits(cache, labels["SK"], "SK", URL_BITS["S1"], True)]
    for arm in ("C", "S1", "S", "K", "SK"):
        checks += claim_checks(cache, labels[arm], claims / ("report-" + arm + ".json"), against=labels["C"],
                               mandatory=False)
    for arm in ("K", "S"):
        checks += [dict(c, check="R-url-bits-" + arm) for c in url_bits(cache, labels[arm], arm, URL_BITS["S1"], False)]
    for arm in ("C-own0", "SK-own0"):
        checks += claim_checks(cache, labels[arm], claims / ("report-" + arm + ".json"), mandatory=False)
    for arm in ("S1", "S"):
        checks += classify(cache, labels[arm], arm)
    return {"verdict": decide(checks), "checks": checks}


def pregate(args, labels):
    cache, claims = args.cache_root.resolve(), HERE / "claims"
    checks = claim_checks(cache, labels["C"], claims / "pregate-C.json")
    checks += [dict(c, check="pregate-url-bits") for c in url_bits(cache, labels["C"], "C", URL_BITS["C"], True)]
    checks += [dict(c, check="pregate-invariants") for c in invariants(cache, labels["C"], labels["C"], V0 + V1 + XA, control_gate=True)]
    return {"verdict": "PRE-GATE PASS" if all(c["status"] == "pass" for c in checks) else "PRE-GATE FAIL",
            "checks": checks}


def counts(delta):
    reason = sum(1 for c in delta["changes"] if c["left"]["type_hash"] == c["right"]["type_hash"])
    return {"R": reason, "T": len(delta["changes"]) - reason, "M": len(delta["left_only"]) + len(delta["right_only"])}


def general(args, labels):
    """H5f: per app pass/fail/unavailable, then failure > generalizes > partial > inconclusive."""
    cache, apps, out = args.cache_root.resolve(), ("forem", "chatwoot", "mastodon", "discourse"), {}
    recs = {arm: records(cache, labels[arm]) for arm in ("C", "S", "SK")}
    for app in apps:
        v1 = V1 if app != "discourse" else ["unset-v1-a1"]
        row, problems, missing, report_missing = {}, [], [], []
        base = {arm: cell(recs[arm], app, "unset-v0-a0") for arm in recs}
        for s in S[1:]:
            for arm in ("C", "S", "SK"):
                a, b = base[arm], cell(recs[arm], app, s + "-v0-a0")
                rows = (obs.observed(a, "reason_rows"), obs.observed(b, "reason_rows")) if a and b else (None, None)
                if None in rows:
                    if arm == "S":
                        if app != "discourse":
                            report_missing.append(arm + "/" + s)
                    else:
                        missing.append(arm + "/" + s)
                    continue
                row[arm + "/" + s] = counts(obs.reason_delta(*rows))
            c0, c1 = base["C"], cell(recs["C"], app, s + "-v0-a0")
            stable = (c0 is not None and c1 is not None and "C/" + s in row and row["C/" + s]["T"] == 0
                      and row["C/" + s]["M"] == 0 and c0["observations"]["value_digests"] == c1["observations"]["value_digests"])
            row["stable/" + s] = stable
            k0, k1 = base["SK"], cell(recs["SK"], app, s + "-v0-a0")
            matched = (c0 is not None and c1 is not None and k0 is not None and k1 is not None
                       and k0["observations"]["value_digests"] == c0["observations"]["value_digests"]
                       and k1["observations"]["value_digests"] == c1["observations"]["value_digests"])
            row["matched/" + s] = matched
            if "SK/" + s in row and "C/" + s in row:
                if matched and row["SK/" + s]["R"] > row["C/" + s]["R"]:
                    problems.append("R(SK) > R(C) at matched " + s)
                if stable and any(row["SK/" + s][k] for k in ("R", "T", "M")):
                    problems.append("SK delta not empty at stable " + s)
        parity = (["unset"] + [s for s in S[1:] if row.get("stable/" + s)]) if any(row.get("stable/" + s) for s in S[1:]) else []
        for s in parity:
            for name in [s + "-v0-a0"] + [n for n in v1 if n.startswith(s + "-")]:
                a, b = cell(recs["C"], app, name), cell(recs["SK"], app, name)
                if a is None or b is None:
                    missing.append("parity " + name)
                elif a["observations"]["value_digests"] != b["observations"]["value_digests"]:
                    problems.append("SK value parity " + name)
        for c in invariants(cache, labels["SK"], labels["C"], V0 + v1, app=app, absolute=False):
            if isinstance(c["detail"], dict) and c["detail"].get("problems"):
                problems.append("SK invariant " + c["scope"] + " " + json.dumps(c["detail"]["problems"]))
            if c["status"] == "unavailable":
                missing.append("SK invariant " + c["scope"])
        compared = any(row.get("stable/" + s) or row.get("matched/" + s) for s in S[1:])
        if not compared:
            missing.append("no stable or matched pair")
        # Generalization's per-app priority is known failure, unavailable, then pass.
        # Value parity covers unset plus C-stable schedules, V0 and scheduled V1.
        status = "fail" if problems else ("unavailable" if missing else "pass")
        out[app] = {"status": status, "problems": problems, "missing": missing,
                    "report_missing": report_missing, "rows": row}
    st = [v["status"] for v in out.values()]
    if "fail" in st:
        verdict = "GENERALIZATION FAILS"
    elif st.count("pass") == 4:
        verdict = "GENERALIZES"
    elif "pass" in st:
        verdict = "PARTIAL: %d of 4 pass, %d unavailable" % (st.count("pass"), st.count("unavailable"))
    else:
        verdict = "GENERALIZATION INCONCLUSIVE"
    return {"verdict": verdict, "apps": out}


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("mode", choices=("pregate", "campfire", "general"))
    p.add_argument("--cache-root", type=Path, required=True)
    p.add_argument("--native", type=Path, help="directory with harness-*.log and laws-* receipts")
    p.add_argument("--label", action="append", default=[], help="ARM=LABEL override")
    p.add_argument("--out", type=Path)
    p.add_argument("--fallback-root", type=Path, help="read fallback.sh cells instead of an obs.py cache")
    args = p.parse_args(argv)
    global FALLBACK
    FALLBACK = args.fallback_root.resolve() if args.fallback_root else None
    labels = {arm: "strict-producer-" + arm for arm in ("C",) + ARMS + ("C-own0", "SK-own0")}
    labels.update(dict(x.split("=", 1) for x in args.label))
    if args.mode == "campfire" and args.native is None:
        p.error("campfire needs --native")
    try:
        result = {"pregate": pregate, "campfire": campfire, "general": general}[args.mode](args, labels)
    except (OSError, ValueError, KeyError, TypeError, AttributeError) as error:
        verdict = {"pregate": "PRE-GATE FAIL", "campfire": "INCONCLUSIVE (unavailable mandatory evidence)",
                   "general": "GENERALIZATION INCONCLUSIVE"}[args.mode]
        result = {"verdict": verdict, "checks": [rec("artifact-schema", args.mode, "unavailable", str(error))]}
    text = json.dumps(result, indent=2, sort_keys=True)
    if args.out:
        args.out.write_text(text + "\n")
    print(result["verdict"])
    return 0


if __name__ == "__main__":
    sys.exit(main())
