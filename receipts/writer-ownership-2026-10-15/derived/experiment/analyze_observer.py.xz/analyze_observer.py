#!/usr/bin/env python3
"""Receipt-backed registered_protocol comparisons. Run under the master heavy lock."""
from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys

D = Path(__file__).resolve().parent
W = D / 'workshop'
C = 'writer-ownership-20261015-bf56edf9'
SCHEDULES = ('unset', '1', '2', 'repeat-unset')
SERIES = ('a', 'b', 'both', 'off')
VALUES = {'attributes', 'block_values', 'constants', 'controller_bindings',
          'controller_cache', 'ir', 'params', 'returns', 'side_table'}
EXPECTED = {('ApplicationController', n, 'Authentication') for n in
            ('authenticated_as', 'require_authentication', 'resume_session',
             'start_new_session_for', 'terminate_current_session')}
EXPECTED |= {('ApplicationController', n, 'TrackedRoomVisit') for n in ('default_room', 'last_room_visited')}
EXPECTED |= {(n, 'set_room', 'RoomScoped') for n in
             ('MessagesController', 'Rooms::InvolvementsController', 'Rooms::RefreshesController')}
index = json.loads((D / 'series-index.json').read_text())
base = json.loads((D / 'baseline-control-index.json').read_text())


def module(name):
    spec = importlib.util.spec_from_file_location(name, W / 'theory' / (name + '.py'))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


support, copyrows = module('support'), module('copyrows')


def save(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')


def output(command, path):
    r = subprocess.run(command, cwd=W, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    path.write_text(r.stdout)
    if r.returncode:
        raise RuntimeError((command, r.returncode, str(path)))


def load(path):
    path = Path(path)
    stderr = (path / 'stderr.log').read_text()
    return {'path': str(path), 'command': json.loads((path / 'command.json').read_text()),
            'report': json.loads((path / 'report.json').read_text()),
            'compact': json.loads((path / 'compact.json').read_text()), 'support': support.load(path),
            'warnings': Counter(re.findall(r'warning\[([a-z_]+)\]', stderr)),
            'errors': Counter(re.findall(r'error\[([a-z_]+)\]', stderr)),
            'diagnostics': Counter(l for l in stderr.splitlines() if re.search(r': (?:warning|error)\[', l)),
            'summary': [l for l in stderr.splitlines() if l.startswith('roundhouse-check:')][-1]}


def inventory_diff(a, b):
    return {k: {'counts': [len(a['support'][k]), len(b['support'][k])],
                'left_only': sorted(a['support'][k] - b['support'][k]),
                'right_only': sorted(b['support'][k] - a['support'][k])}
            for k in ('attempted', 'concrete', 'mutation')}


def compare(a, b):
    return {'left': a['path'], 'right': b['path'], 'inventories': inventory_diff(a, b),
            'declarations_equal': a['compact']['declaration_hashes'] == b['compact']['declaration_hashes'],
            'digest_equal': {k: a['report']['digest'].get(k) == b['report']['digest'].get(k)
                             for k in a['report']['digest'].keys() | b['report']['digest'].keys()},
            **{k + '_equal': a[k] == b[k] for k in ('warnings', 'errors', 'diagnostics', 'summary')},
            **{k + '_equal': a['report'][k] == b['report'][k] for k in ('census', 'loops', 'fold', 'entries')}}


def empty(pair, category):
    return not pair['inventories'][category]['left_only'] and not pair['inventories'][category]['right_only']


def identical(pair):
    return (pair['declarations_equal'] and all(pair['digest_equal'].values())
            and all(empty(pair, k) for k in ('attempted', 'concrete', 'mutation'))
            and all(pair[k + '_equal'] for k in ('warnings', 'errors', 'diagnostics', 'summary',
                                                'census', 'loops', 'fold', 'entries')))


def fixture_fixture_criterion(pair):
    # registered_protocol H1.7 names the identity comparison and the nine emitted digests.
    # It does not require schedule-dependent fold work counters to be equal.
    return (pair['declarations_equal'] and all(pair['digest_equal'].values())
            and len(pair['digest_equal']) == 9
            and all(pair['inventories'][k]['counts'] == [10, 10] and empty(pair, k)
                    for k in ('attempted', 'mutation')))


def settled(run):
    return all(v['end'] == 'settled' for v in run['report']['loops'].values())


baselines = {label: load(path) for label, path in base.items()}
runs = {x: {label: load(path) for label, path in index[x].items()} for x in SERIES}
pairs, ownership = {}, {}
for x in SERIES:
    out = W / 'theory/runs' / (C + '-' + x)
    camps = [index[x]['campfire-' + s] for s in SCHEDULES]
    for s in SCHEDULES[1:]:
        for extension in ('txt', 'json'):
            command = ['./diff.sh', camps[0], index[x]['campfire-' + s]]
            if extension == 'json':
                command += ['--json']
            output(command, out / ('diff-unset--' + s + '.' + extension))
        pairs[x + '/unset--' + s] = compare(runs[x]['campfire-unset'], runs[x]['campfire-' + s])
    baseline_camps = [base['campfire-' + s] for s in ('unset', '1', '2')]
    output([sys.executable, '-I', 'theory/support.py', *camps, *baseline_camps,
            '--out', str(out / 'support.json')], out / 'support.txt')
    output([sys.executable, '-I', 'theory/digests.py', *camps, *baseline_camps], out / 'digests.txt')
    warning_rows = []
    for label, run in runs[x].items():
        pairs[x + '/' + label + '--baseline-matched'] = compare(run, baselines[label])
        warning_rows += [run['path'], json.dumps(run['warnings'], sort_keys=True),
                         json.dumps(run['errors'], sort_keys=True), run['summary']]
        if x in ('a', 'both', 'off'):
            b = baselines[label]
            output([sys.executable, '-I', 'theory/copyrows.py', b['path'], run['path']],
                   out / ('copyrows.txt' if label == 'campfire-unset' else 'copyrows-' + label + '.txt'))
            bs, br, bw, bo = copyrows.rows(b['path'])
            cs, cr, cw, co = copyrows.rows(run['path'])
            removed = {(r[4], r[6], r[1]) for r in br - cr}
            removed_writers = {(r[0], r[2], r[3]) for r in bw - cw}
            ownership[x + '/' + label] = {'removed_routes': sorted(removed),
                                          'removed_writers': sorted(removed_writers),
                                          'added_routes': sorted(cr - br), 'added_writers': sorted(cw - bw),
                                          'other_routes_removed': sorted(bo - co),
                                          'other_routes_added': sorted(co - bo),
                                          'other_routes_equal': bo == co, 'spliced_slots_equal': bs == cs,
                                          'concern_routes': [len(br), len(cr)],
                                          'exact_expected_change': removed == removed_writers ==
                                          (EXPECTED if x != 'off' and label.startswith('campfire') else set())
                                          and not (cr - br) and not (cw - bw) and bo == co and bs == cs}
    (out / 'warnings.txt').write_text('\n'.join(warning_rows) + '\n')
    if x in ('a', 'off'):
        for extension in ('txt', 'json'):
            command = ['./diff.sh', index[x]['fixture-unset'], index[x]['fixture-1']]
            if extension == 'json': command += ['--json']
            output(command, out / ('diff-fixture.' + extension))
        pairs[x + '/fixture-unset--1'] = compare(runs[x]['fixture-unset'], runs[x]['fixture-1'])

output([sys.executable, '-I', 'theory/digests.py',
        *(index[x]['fixture-' + s] for x in ('a', 'off') for s in ('unset', '1')),
        base['fixture-unset'], base['fixture-1']],
       W / 'theory/runs' / (C + '-a') / 'fixture-digests.txt')

summary = {'condition': C, 'baseline_condition': 'writer-ownership-baseline-bf56edf9-s3-observe-v1',
           'matched_comparisons': pairs, 'ownership': ownership, 'runs': {}}
for x, series in [('baseline', baselines), *runs.items()]:
    for label, r in series.items():
        summary['runs'][x + '/' + label] = {
            'path': r['path'], 'command': r['command'],
            **{k: dict(r[k]) for k in ('warnings', 'errors')}, 'summary': r['summary'],
            'inventories': {k: len(r['support'][k]) for k in ('attempted', 'concrete', 'mutation')},
            **{k: r['report'][k] for k in ('digest', 'entries', 'census', 'fold', 'loops')}}

a_pairs = [pairs['a/unset--' + s] for s in SCHEDULES[1:]]
a_matched = [pairs['a/campfire-' + s + '--baseline-matched'] for s in SCHEDULES]
fresh = json.loads((D / 'baseline-diff.json').read_text())
base_unset = baselines['campfire-unset']['support']['mutation']
extra = runs['a']['campfire-unset']['support']['mutation'] - base_unset
added_names = {(json.loads(t)[0], json.loads(t)[2], json.loads(p)[2]) for p, t in extra}
ten_credited = all(
    {(json.loads(t)[0], json.loads(t)[2]) for p, t in runs['a']['campfire-' + s]['support']['mutation']
     if json.loads(p)[2] == 'no-body'} >= {(c, n) for c, n, _ in EXPECTED}
    for s in SCHEDULES)
a_census = {'typed': 32505, 'untyped_anywhere': 4816, 'bare_untyped': 4151}
expected_prov = lambda s, b=False: {'pending': 0, 'gradual': 642 if s == '2' else 649,
                                   'unresolved': (4173 if b else 4182) if s == '2' else (4166 if b else 4175)}
expected_loops = {k: {'end': 'settled', 'round': n} for k, n in
                  [('production', 3), ('views_and_tests', 4), ('absorb', 1)]}
expected_fold = lambda f: f['methods_in_reference_mode'] == 9 and f['side_table_nodes'] == 22 and all(
    f['slots'][k] == n for k, n in [('narrow', 13), ('param', 4), ('ret', 12)])
off_ok = all(identical(pairs['off/' + label + '--baseline-matched']) for label in runs['off'])
baseline_counts = [len(r['support']['concrete']) for r in baselines.values() if r['command']['app'] == 'campfire']
concrete_equal = all(r['support']['concrete'] == baselines['campfire-unset']['support']['concrete']
                     for series in runs.values() for label, r in series.items() if label.startswith('campfire'))
concrete_equal &= all(baselines['campfire-' + s]['support']['concrete'] ==
                      baselines['campfire-unset']['support']['concrete'] for s in SCHEDULES)

a_confirm = {
    '1_baseline_puzzle': fresh['declarations_equal'] and fresh['attempt']['counts'] == [740, 740]
        and fresh['mutation']['counts'] == [678, 678]
        and {json.loads(r[2])[2] for r in fresh['mutation']['left_only']} ==
            {'require_authentication', 'terminate_current_session'}
        and {json.loads(r[2])[2] for r in fresh['mutation']['right_only']} == {'resume_session', 'start_new_session_for'},
    '2_schedule_identity': all(p['declarations_equal'] and empty(p, 'attempted') and empty(p, 'mutation')
                               and p['inventories']['attempted']['counts'] == [740, 740] for p in a_pairs),
    '3_support_and_681_mutations': concrete_equal and all(
        p['inventories']['attempted']['counts'] == [740, 740] and empty(p, 'attempted')
        and p['inventories']['concrete']['counts'] == [556, 556] and empty(p, 'concrete') for p in a_matched)
        and all(len(runs['a']['campfire-' + s]['support']['mutation']) == 681 for s in SCHEDULES)
        and base_unset <= runs['a']['campfire-unset']['support']['mutation'] and added_names ==
        {('ApplicationController', n, 'no-body') for n in ('authenticated_as', 'resume_session', 'start_new_session_for')}
        and ten_credited,
    '4_exact_ownership': all(o['exact_expected_change'] for key, o in ownership.items()
                             if key.startswith(('a/', 'off/')))
        and len({runs['a']['campfire-' + s]['report']['digest']['copies'] for s in SCHEDULES}) == 1
        and all(runs['a']['campfire-' + s]['report']['digest']['copies'] != '1480317c738af0bb'
                and runs['a']['campfire-' + s]['report']['entries']['copies'] == 16
                and a_matched[i]['fold_equal'] and expected_fold(runs['a']['campfire-' + s]['report']['fold'])
                for i, s in enumerate(SCHEDULES))
        and all(runs['off']['campfire-' + s]['report']['digest']['copies'] == '1480317c738af0bb' for s in SCHEDULES),
    '5_matched_values_census': all(all(p['digest_equal'][k] for k in VALUES) and p['census_equal'] for p in a_matched)
        and all(all(runs['a']['campfire-' + s]['report']['census'][k] == v for k, v in a_census.items())
                and runs['a']['campfire-' + s]['report']['census']['untyped_by_provenance'] == expected_prov(s)
                for s in SCHEDULES),
    '6_warnings_and_loops': all(r['warnings'] == {'gradual_untyped': 245, 'unresolved_type': 161, 'missing_preload': 1}
        and not r['errors'] and r['report']['loops'] == expected_loops for label, r in runs['a'].items()
        if label.startswith('campfire')) and all(p['warnings_equal'] and p['loops_equal'] for p in a_matched),
    '7_fixture': fixture_fixture_criterion(pairs['a/fixture-unset--1']) and all(
        fixture_fixture_criterion(pairs['a/fixture-' + s + '--baseline-matched'])
        and len(runs['a']['fixture-' + s]['support']['attempted']) == 10
        and len(runs['a']['fixture-' + s]['support']['mutation']) == 10
        and len(runs['a']['fixture-' + s]['report']['digest']) == 9 for s in ('unset', '1')),
    '8_flags_off_matched': off_ok,
}

b_pairs = [pairs['b/unset--' + s] for s in SCHEDULES[1:]]
b_confirm = {
    '1_all_ten_digests_equal': all(all(p['digest_equal'].values()) for p in b_pairs)
        and all(len(runs['b']['campfire-' + s]['report']['digest']) == 10
                and runs['b']['campfire-' + s]['report']['digest']['copies'] == '1480317c738af0bb' for s in SCHEDULES),
    '2_expected_baseline_changes': all(
        {k for k, same in pairs['b/campfire-' + s + '--baseline-matched']['digest_equal'].items() if not same}
        == {'returns', 'ir', 'controller_cache'}
        and runs['b']['campfire-' + s]['report']['census']['untyped_anywhere'] == 4807
        and pairs['b/campfire-' + s + '--baseline-matched']['warnings_equal']
        and pairs['b/campfire-' + s + '--baseline-matched']['loops_equal'] for s in SCHEDULES),
    '3_provenance_recorded_without_judgment': True,
    '4_both_composes': all(
        runs['both']['campfire-' + s]['support']['mutation'] == runs['a']['campfire-' + s]['support']['mutation']
        and ownership['both/campfire-' + s]['exact_expected_change']
        and all(runs['both']['campfire-' + s]['report']['digest'][k] ==
                runs['b']['campfire-' + s]['report']['digest'][k] for k in VALUES)
        and runs['both']['campfire-' + s]['report']['digest']['copies'] ==
            runs['a']['campfire-' + s]['report']['digest']['copies'] for s in SCHEDULES),
}
a_kills, b_kills = [], []
spliced = {(c, n) for c, n, _ in EXPECTED}
if any((json.loads(t)[0], json.loads(t)[2]) in spliced
       for p in a_pairs for side in ('left_only', 'right_only') for _, t in p['inventories']['mutation'][side]):
    a_kills.append('A spliced-slot mutation identities differ across schedules')
if any(o['added_routes'] or o['added_writers'] or o['other_routes_added']
       or any(tuple(row) not in EXPECTED for row in o['removed_routes'])
       for k, o in ownership.items() if k.startswith('a/')):
    a_kills.append('undeclared ownership effect')
if not concrete_equal: a_kills.append('concrete support differs')
if any(not all(p['digest_equal'][k] for k in VALUES) for p in a_matched):
    a_kills.append('A matched value-level digest differs; extended focus required by card')
for x in SERIES:
    for label, r in runs[x].items():
        arm_kills = b_kills if x in ('b', 'both') else a_kills
        if any(n > baselines[label]['warnings'].get(k, 0) for k, n in r['warnings'].items()):
            arm_kills.append(x + '/' + label + ': warnings rise')
        if not settled(r):
            arm_kills.append(x + '/' + label + ': loop not settled')
if not off_ok: a_kills.append('flags-off matched baseline differs')
if any(not all(p['digest_equal'][k] for k in VALUES) for p in b_pairs):
    b_kills.append('B value-level digest differs across schedules')

verdict = lambda criteria, kills: 'killed' if kills else 'confirmed' if all(criteria.values()) else 'inconclusive'
audit = {'condition': C, 'H1': {'verdict': verdict(a_confirm, a_kills), 'confirm': a_confirm, 'kills': a_kills},
         'H2': {'verdict': verdict(b_confirm, b_kills), 'confirm': b_confirm, 'kills': b_kills},
         'H3': {'status': 'diagnostic only; no verdict'}, 'added_mutation_identities': sorted(extra),
         'all_ten_spliced_slots_credited': ten_credited, 'all_campfire_concrete_support_equal': concrete_equal,
         'B_provenance': {s: runs['b']['campfire-' + s]['report']['census']['untyped_by_provenance'] for s in SCHEDULES}}
save(D / 'comparisons.json', summary)
save(D / 'gate-audit.json', audit)
print(json.dumps(audit, indent=2))
