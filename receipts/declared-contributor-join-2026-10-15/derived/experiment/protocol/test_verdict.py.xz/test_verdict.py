#!/usr/bin/env python3
"""Tests for CARD-RESEARCH_PROFILE's verdict machinery on synthetic observer cells (no analyzer, under a second).

  python3 -I -m unittest discover -s phase2/contributor-ownership/contributor-protocol -p 'test_*.py' -v
"""
import hashlib
import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import verdict as V  # noqa: E402

U = {"kind": "untyped"}
NIL = {"kind": "nil"}
STR = {"kind": "str"}
VAR = {"kind": "var", "var": 0}
BOOL = {"kind": "bool"}


def union(*xs):
    return {"kind": "union", "variants": list(xs)}


def cls(name):
    return {"kind": "class", "id": name, "args": []}


DIGESTS = {t: "0" * 16 for t in V.TABLES}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


class Lab:
    """A temporary observer cache with labels whose cells are written directly."""

    def __init__(self):
        self.root = Path(tempfile.mkdtemp())
        self.n = 0

    def close(self):
        shutil.rmtree(self.root)

    def cell(self, label, app, setting, rows=None, digests=None, stderr=(), verify=None, census=None,
             diagnostics=None, loops=None, valid=True, closure=None, dump=True):
        self.n += 1
        d = self.root / "objects" / ("%02d" % self.n) / "key" / "attempt"
        d.mkdir(parents=True)
        digests = dict(DIGESTS, **(digests or {}))
        report = {"digest": digests, "loops": loops or {k: {"end": "settled", "round": 3} for k in ("production", "views_and_tests", "absorb")},
                  "worklist": {"engine": {"cap_hits": 0, "budget_exhausted": 0}}, "fold": {"expansion": {"budget_cuts": 0}}}
        (d / "report.json").write_text(json.dumps(report))
        lines = list(stderr)
        if closure is not None:
            lines.insert(0, "rh-contributor-closure: " + json.dumps(closure))
        (d / "stderr.log").write_text("\n".join(lines) + "\n")
        if dump:
            with (d / "contributor-values.jsonl").open("w") as out:
                counts = {p: sum(part == p for part, key in (rows or {}))
                          for p in V.VALUE_PARTS + ("aliases",)}
                aliases = {key: "Authentication" for part, key in (rows or {}) if part == "aliases"}
                out.write(json.dumps({"part": "fingerprint", "digests": digests,
                                      "row_counts": counts, "alias_inventory": aliases}) + "\n")
                for (part, key), ty in sorted((rows or {}).items()):
                    out.write(json.dumps({"part": part, "key": key, "ty": ty,
                                          "module": aliases.get(key),
                                          "hash": hashlib.md5(json.dumps(ty, sort_keys=True).encode()).hexdigest()})
                              + "\n")
                out.write(json.dumps({"part": "complete", "row_counts": counts}) + "\n")
        (d / "reason-rows.json").write_text("{}")
        census = census or {"untyped_anywhere": 10, "untyped_by_provenance": {"pending": 0}}
        result = {"valid": valid, "directory": str(d), "observations": {
            "value_digests": digests, "reason_census": census,
            "reason_rows": {"file": "reason-rows.json", "sha256": sha(d / "reason-rows.json"), "count": 0},
            "successful_writes": None, "law_violation_counts": None, "diagnostics": diagnostics or {},
            "loops": report["loops"], "verify": verify, "exit_code": 0}}
        (d / "result.json").write_text(json.dumps(result))
        lab = self.root / "labels" / label / "label.json"
        lab.parent.mkdir(parents=True, exist_ok=True)
        data = json.loads(lab.read_text()) if lab.exists() else {"cells": {}}
        data["cells"][app + "/" + setting] = {"result": str(d / "result.json"), "valid": valid, "cache_hit": False,
                                              "fresh_match": None, "cache_key": "k%d" % self.n}
        lab.write_text(json.dumps(data))


VERIFY0 = [{"loop": k, "moved": {t: 0 for t in V.TABLES}}
           for k in ("production", "views_and_tests", "absorb")]
CLOSURE = {"targets": [["SessionsController", "require_authentication", "Authentication"]],
           "excluded_declared": [], "modules": ["Authentication"],
           "classes": ["Authentication", "SessionsController", "ActionView::Base"]}
RET = ("returns", "SessionsController#require_authentication")
OUT = ("returns", "Opengraph::Fetch#request")


def cell_records(stored, ok=True):
    agg = {"target": "SessionsController#require_authentication", "phase": "prefinal", "own": stored,
           "module_cells": {"Authentication": stored}, "aggregate": stored, "stored": stored,
           "aggregate_hash": "h", "stored_hash": "h" if ok else "x", "replay_equal": ok, "perm_equal": True,
           "reference_mode": False}
    return ["rh-contributor-cell: " + json.dumps(agg),
            "rh-contributor-summary: " + json.dumps({"targets": 1, "own_present": 1, "module_present": 1,
                                         "replay_failures": 0 if ok else 1, "perm_failures": 0})]


def digest_of(ty):
    return hashlib.sha256(json.dumps(ty, sort_keys=True).encode()).hexdigest()[:16]


def campfire_lab(join_value_2=None, race=True, drop_join_cell=None, replay_ok=True, flip=False):
    lab = Lab()
    full = union(STR, U, NIL)
    alias = ("aliases", "SessionsController#require_authentication")
    for s in V.CAMPFIRE:
        sched2 = s.startswith("2-")
        c_ret = union(STR, NIL) if (sched2 and race) else full
        verify = VERIFY0 if "-v1-" in s else None
        # flip: main's own order dependence outside the family (OUT is untyped on schedule 1 only)
        out_c = U if (flip and s.startswith("1-")) else STR
        rows_c = {RET: c_ret, OUT: out_c, alias: None}
        for label in ("contributor-join-control", "s1b-spine-ownership-off"):
            lab.cell(label, "campfire", s, rows=rows_c, digests={"returns": digest_of(c_ret)}, verify=verify,
                     closure=CLOSURE)
        if drop_join_cell == s:
            continue
        j_ret = join_value_2 if (sched2 and join_value_2 is not None) else full
        lab.cell("contributor-join-join", "campfire", s, rows={RET: j_ret, OUT: STR, alias: None},
                 digests={"returns": digest_of(j_ret)}, verify=verify, closure=CLOSURE,
                 stderr=cell_records(j_ret, replay_ok))
    return lab


def native_and_defaults(root):
    nat = root / "native"
    nat.mkdir()
    counts = {k: 0 for k in ("comm", "assoc", "idem", "identity", "keeps_unknown", "arrival")}
    (nat / "contributor-join-laws.log").write_text("RESEARCH_PROFILE-JOIN-LAWS " + json.dumps({"counts": counts, "cases": 400}) + "\n")
    (nat / "contributor-join-laws.exit").write_text("0\n")
    (nat / "lib-suite.log").write_text("test result: ok. 1238 passed; 0 failed; 21 ignored\n")
    (nat / "lib-suite.exit").write_text("0\n")
    dfl = root / "defaults"
    for mode in ("on", "off"):
        d = dfl / mode / "unset"
        d.mkdir(parents=True)
        src = V.DEFAULTS_RECEIPTS / mode / "unset"
        shutil.copy(src / "report.json", d / "report.json")
        shutil.copy(src / "probe-campfire.stderr", d / "probe-campfire.stderr")
        (d / "exit").write_text("0\n")
    return nat, dfl


def run_campfire(lab):
    nat, dfl = native_and_defaults(lab.root)
    args = V.argparse.Namespace(cache_root=lab.root, label=["A=s1b-spine-ownership-off"], native=nat, defaults=dfl)
    return V.mode_campfire(args)


class Sets(unittest.TestCase):
    def test_relations(self):
        self.assertEqual(V.relation(U, union(NIL, U)), "EQ")
        self.assertEqual(V.relation(U, NIL), "NARROW")
        self.assertEqual(V.relation(union(STR, NIL), union(STR, U, NIL)), "WIDEN")
        self.assertEqual(V.relation(None, NIL), "STRUCT")
        self.assertEqual(V.relation(union(BOOL, NIL), BOOL), "NARROW")
        self.assertEqual(V.relation(cls("Account"), cls("User")), "INCOMP")

    def test_var_only_loss(self):
        self.assertEqual(V.relation(union(STR, VAR), STR), "NARROW")
        self.assertTrue(V.var_only_loss(union(STR, VAR), STR))
        self.assertFalse(V.var_only_loss(U, NIL))

    def test_admits(self):
        self.assertTrue(V.admits(U, "String"))
        self.assertTrue(V.admits(union(BOOL, NIL), "NilClass"))
        self.assertFalse(V.admits(union(STR, NIL), "Integer"))
        self.assertTrue(V.admits(union(cls("Account"), NIL), "Account"))
        self.assertFalse(V.admits(NIL, "String"))

    def test_meet(self):
        self.assertEqual(V.meet(union(STR, U, NIL), union(STR, NIL)), union(STR, NIL))
        self.assertEqual(V.meet(union(STR, NIL), union(NIL, BOOL)), NIL)
        self.assertEqual(V.meet(STR, BOOL), {"kind": "bottom"})
        self.assertIsNone(V.meet(None, STR))
        floor = V.meet(V.meet(U, union(cls("Account"), NIL)), U)
        self.assertTrue(V.covers(union(cls("Account"), NIL, U), floor))
        self.assertFalse(V.covers(NIL, floor))

    def test_unresolved_reference_is_unavailable(self):
        with self.assertRaises(KeyError):
            V.covers(NIL, {"kind": "rec", "slot": "x"})

    def test_root_class(self):
        self.assertEqual(V.root_class("controller_cache", "Api::V0::ListingsController#create:body:5/1/0"),
                         "Api::V0::ListingsController")
        self.assertEqual(V.root_class("returns", "Foo::Bar.baz"), "Foo::Bar")
        self.assertEqual(V.root_class("params", "Foo::Bar#baz[0]"), "Foo::Bar")
        key = '{"kind":"Send","source":"[\\"[\\\\\\"Ahoy::Event\\\\\\",\\\\\\"class-body\\\\\\"]\\",\\"0\\"]",' \
              '"span":{"end":272,"file":5,"start":246}}:occurrence:0:'
        self.assertEqual(V.root_class("ir", key), "Ahoy::Event")
        self.assertEqual(V.root_class("side_table", 'Some(Param { class: ClassId(Symbol("Images::Optimizer")), '
                                                    'method: Symbol("x"), side: Class, index: 0 })'),
                         "Images::Optimizer")
        self.assertIsNone(V.root_class("side_table", "Some(Narrow { site: (966, 1, 2) })"))


class Decisions(unittest.TestCase):
    def test_order(self):
        p = V.rec("x", "s", "pass")
        f = V.rec("x", "s", "fail")
        u = V.rec("x", "s", "unavailable")
        r = V.rec("x", "s", "fail", mandatory=False)
        self.assertEqual(V.decide([p, u, f]), "KILLED")
        self.assertEqual(V.decide([p, f], pregate=[u]), "KILLED")
        self.assertEqual(V.decide([p], pregate=[f]), "INCONCLUSIVE (pre-gate)")
        self.assertEqual(V.decide([p, u]), "INCONCLUSIVE")
        self.assertEqual(V.decide([p, r]), "CONFIRMED")

    def test_rollup(self):
        self.assertEqual(V.rollup("KILLED")["card"], "KILLED")
        self.assertEqual(V.rollup("KILLED")["H2"], "NOT RUN")
        self.assertEqual(V.rollup("INCONCLUSIVE (pre-gate)", "CONFIRMED")["card"], "INCONCLUSIVE (pre-gate)")
        self.assertEqual(V.rollup("CONFIRMED", "KILLED")["card"], "KILLED")
        self.assertEqual(V.rollup("CONFIRMED", "INCONCLUSIVE")["card"], "INCONCLUSIVE")
        self.assertEqual(V.rollup("CONFIRMED", "CONFIRMED", "KILLED")["card"], "CONFIRMED")
        self.assertEqual(V.rollup("CONFIRMED")["card"], "INCONCLUSIVE")


class Campfire(unittest.TestCase):
    def check(self, lab, expected):
        try:
            result = run_campfire(lab)
            bad = [(c["check"], c["scope"], c["status"]) for c in result["checks"] if c["status"] != "pass"]
            self.assertEqual(result["verdict"], expected, bad)
            return result
        finally:
            lab.close()

    def test_confirmed_when_the_race_is_gone(self):
        self.check(campfire_lab(), "CONFIRMED")

    def test_killed_when_the_join_still_differs_across_schedules(self):
        result = self.check(campfire_lab(join_value_2=union(STR, NIL)), "KILLED")
        self.assertTrue(any(c["check"] == "C-schedules" and c["status"] == "fail" for c in result["checks"]))

    def test_killed_when_join_drops_the_unknown_arm(self):
        result = self.check(campfire_lab(join_value_2=NIL), "KILLED")
        self.assertTrue(any(c["check"] == "K1-floor" and c["status"] == "fail" for c in result["checks"]))

    def test_inconclusive_without_the_race(self):
        self.check(campfire_lab(race=False), "INCONCLUSIVE (pre-gate)")

    def test_inconclusive_with_a_missing_cell(self):
        self.check(campfire_lab(drop_join_cell="repeat-v1-a1"), "INCONCLUSIVE")

    def test_floor_tolerates_an_order_flip_main_itself_shows(self):
        self.check(campfire_lab(flip=True), "CONFIRMED")

    def test_killed_when_replay_fails(self):
        self.check(campfire_lab(replay_ok=False), "KILLED")


class CrossCheck(unittest.TestCase):
    """A single-schedule cross-check borrows main's v0-a0 envelope only where C's digests show the table equal."""

    def run_lab(self, ir_differs):
        lab = Lab()
        try:
            row = ("ir", '{"kind":"Send","source":"[\\"[\\\\\\"Foo\\\\\\",\\\\\\"instance\\\\\\",'
                          '\\\\\\"bar\\\\\\"]\\",\\"body\\"]","span":{"end":2,"file":1,"start":1}}:occurrence:0:')
            for n in V.FIVE:
                c_val = U if n == "1-v0-a0" else STR          # main flips this row on schedule 1
                if n == "unset-v1-a1":
                    c_val = U                                  # and lands on the wide value at the cross-check
                dig = {"ir": "v1" if (ir_differs and n == "unset-v1-a1") else "0" * 16}
                lab.cell("c", "forem", n, rows={row: c_val}, digests=dig, closure=CLOSURE)
                lab.cell("j", "forem", n, rows={row: STR}, digests=dig, closure=CLOSURE,
                         stderr=["rh-contributor-summary: " + json.dumps({"targets": 0, "replay_failures": 0})])
            recs_c, recs_j = V.records(lab.root, "c"), V.records(lab.root, "j")
            checks, _ = V.check_floor_and_scope(recs_c, recs_j, "forem", V.FIVE, False)
            return {(c["check"], c["scope"]): c["status"] for c in checks}
        finally:
            lab.close()

    def test_borrows_the_envelope_where_the_table_is_equal(self):
        got = self.run_lab(ir_differs=False)
        self.assertEqual(got[("K1-floor", "forem/unset-v1-a1")], "pass")
        self.assertEqual(got[("K1-floor", "forem/1-v0-a0")], "pass")

    def test_reports_instead_of_gating_where_the_table_differs(self):
        got = self.run_lab(ir_differs=True)
        self.assertEqual(got[("K1-floor", "forem/unset-v1-a1")], "pass")
        self.assertEqual(got[("K1-no-envelope", "forem/unset-v1-a1")], "report")


class Witnesses(unittest.TestCase):
    def test_floor_is_relative_to_control(self):
        lab = Lab()
        try:
            key = ("returns", "ListingsController#create_draft")
            lab.cell("c", "forem", "unset-v0-a0", rows={key: U})
            lab.cell("j", "forem", "unset-v0-a0", rows={key: NIL})
            lab.cell("j2", "forem", "unset-v0-a0", rows={key: union(NIL, U)})
            recs = {x: V.records(lab.root, x) for x in ("c", "j", "j2")}
            wmap = json.loads((HERE / "witness-map.json").read_text())
            wmap["witnesses"] = [w for w in wmap["witnesses"] if w["key_regex"] == key[1]]
            bad = V.check_witnesses(recs["c"], recs["j"], "forem", ["unset-v0-a0"], wmap)
            good = V.check_witnesses(recs["c"], recs["j2"], "forem", ["unset-v0-a0"], wmap)
            self.assertEqual(bad[0]["status"], "fail")
            self.assertEqual(good[0]["status"], "pass")
        finally:
            lab.close()


if __name__ == "__main__":
    unittest.main()
