#!/usr/bin/env python3
"""CARD-research condition verdicts: every mandatory check, every report-only measurement, and one decision order.

Python 3.9, standard library plus phase2/observers/obs.py. Reads recorded cells only; never runs the analyzer.

  verdict.py pregate   --cache-root CACHE [--label ARM=LABEL ...] [--out FILE]
  verdict.py campfire  --cache-root CACHE --native DIR --defaults DIR [--label ...] [--out FILE]
  verdict.py general   --cache-root CACHE [--label ...] [--out FILE]      # H2: forem, chatwoot, mastodon
  verdict.py discourse --cache-root CACHE [--label ...] [--out FILE]      # H3, reported outside the roll-up
  verdict.py rollup    --campfire FILE [--general FILE] [--discourse FILE] [--out FILE]

Arms (override with --label ARM=LABEL): C = contributor-join-control, J = contributor-join-join, S = s1b-spine-ownership-off (spine
binary, phase B), A = s1b-spine-ownership-on (report only).

A check is pass, fail or unavailable. Decision for one hypothesis, in this order:
  1. KILLED if any mandatory check in its scope failed on valid evidence (an observed failure wins);
  2. INCONCLUSIVE (pre-gate) if the pre-gate did not pass (H1 only);
  3. INCONCLUSIVE if any mandatory check is unavailable;
  4. CONFIRMED otherwise.
Report-only records never change a verdict. Roll-up: H1 not CONFIRMED -> the card takes H1's verdict and H2 is
NOT RUN; else KILLED / INCONCLUSIVE / CONFIRMED by H2. H3 (Discourse) is reported beside the roll-up.
"""
import argparse
import hashlib
import json
import re
import sys
from functools import wraps
from pathlib import Path

HERE = Path(__file__).resolve().parent
F = HERE.parents[2]
sys.path.insert(0, str(F / "phase2/observers"))
import obs  # noqa: E402

RECEIPT_SCHEDULES = ("unset", "1", "2", "repeat")
V0 = [s + "-v0-a0" for s in RECEIPT_SCHEDULES]
V1 = [s + "-v1-a1" for s in RECEIPT_SCHEDULES]
FIVE = V0 + ["unset-v1-a1"]
CAMPFIRE = V0 + V1
DISCOURSE = ["unset-v0-a0", "1-v0-a0"]
TABLES = ("attributes", "block_values", "constants", "controller_bindings", "controller_cache", "copies", "ir",
          "params", "returns", "side_table")
PARITY_FIELDS = ("value_digests", "reason_census", "reason_rows", "diagnostics", "loops", "verify", "exit_code")
VALUE_PARTS = ("returns", "params", "controller_cache", "ir", "side_table")
SPINE = F / "agents/storage-repair-five-apps"
DEFAULTS_RECEIPTS = SPINE / "evidence/spine-main-a5d73fdf-v1/campfire/defaults"
DIAG = re.compile(r"\b(?P<sev>warning|error)\[(?P<kind>[^\]]+)\]:")  # the same pattern obs.py counts
CLASS_IN_KEY = re.compile(r'ClassId\(Symbol\(("(?:\\.|[^"])*")\)\)')
RET_SLOT = re.compile(r'Some\(Ret \{ class: ClassId\(Symbol\(("(?:\\.|[^"])*")\)\), '
                      r'method: Symbol\(("(?:\\.|[^"])*")\), class_side: (true|false) \}\)')


def rec(name, scope, status, detail=None, mandatory=True):
    return {"check": name, "scope": scope, "status": status, "mandatory": mandatory, "detail": detail}


def evidence_guard(name, report=False):
    """Expected read/schema failures affect this independent check, never the decision procedure."""
    def decorate(fn):
        @wraps(fn)
        def guarded(*args, **kwargs):
            try:
                return fn(*args, **kwargs)
            except (OSError, ValueError, KeyError, TypeError, AttributeError, IndexError) as error:
                mandatory = not report and kwargs.get("mandatory", True)
                r = rec(name, "unreadable evidence", "report" if report else "unavailable", str(error), mandatory)
                return r if report else [r]
        return guarded
    return decorate


# ---------------------------------------------------------------- types as sets of Ruby values

VAR_TOP = True  # a raw Var prints as `untyped` (src/rbs.rs:1188); --var-pending flips the reading


def top(t):
    k = t.get("kind") if isinstance(t, dict) else None
    if k == "untyped":
        return True
    if k == "var":
        return VAR_TOP
    if k == "union":
        return any(top(v) for v in t["variants"])
    return False


def empty(t):
    k = t.get("kind")
    if k == "bottom":
        return True
    if k == "var":
        return not VAR_TOP
    if k == "union":
        return all(empty(v) for v in t["variants"])
    return False


def arms(t):
    if t.get("kind") == "union":
        out = []
        for v in t["variants"]:
            out.extend(arms(v))
        return out
    return [t]


def covers(a, b):
    """The values `a` admits include every value `b` admits. Raises KeyError on an unresolved reference."""
    if empty(b) or top(a):
        return True
    if b.get("kind") == "rec" or a.get("kind") == "rec":
        raise KeyError("unresolved reference")
    if b.get("kind") == "union":
        return all(covers(a, v) for v in b["variants"] if not empty(v))
    if top(b):
        return False
    return any(covers1(x, b) for x in arms(a) if not empty(x))


def covers1(a, b):
    ka, kb = a.get("kind"), b.get("kind")
    if top(a):
        return True
    if ka == "rec" or kb == "rec":
        raise KeyError("unresolved reference")
    if ka != kb:
        return False
    if ka == "class":
        aa, ba = a.get("args") or [], b.get("args") or []
        return a.get("id") == b.get("id") and len(aa) == len(ba) and all(covers(x, y) for x, y in zip(aa, ba))
    if ka == "array":
        return covers(a["elem"], b["elem"])
    if ka == "hash":
        return covers(a["key"], b["key"]) and covers(a["value"], b["value"])
    if ka == "tuple":
        ea, eb = a.get("elems") or [], b.get("elems") or []
        return len(ea) == len(eb) and all(covers(x, y) for x, y in zip(ea, eb))
    if ka == "fn":
        return covers(a.get("ret") or {"kind": "untyped"}, b.get("ret") or {"kind": "untyped"})
    if ka in ("nil", "str", "sym", "bool", "int", "float", "date", "time", "self_instance"):
        return True
    return a == b  # records, relations and anything new: only identical shapes cover


def relation(control, join):
    """Relation of the join arm to the control at one row: EQ, WIDEN, NARROW, INCOMP or STRUCT."""
    if control is None or join is None:
        return "STRUCT"
    up, down = covers(join, control), covers(control, join)
    if up and down:
        return "EQ"
    if up:
        return "WIDEN"
    return "NARROW" if down else "INCOMP"


def var_only_loss(control, join):
    """True when every arm the join drops is a raw Var: no verdict under the Var-pending reading."""
    global VAR_TOP
    saved, VAR_TOP = VAR_TOP, False
    try:
        return covers(join, control)
    finally:
        VAR_TOP = saved


def meet(a, b):
    """The values both admit (None stands for an absent row and stays absent)."""
    if a is None or b is None:
        return None
    if top(a):
        return b
    if top(b):
        return a
    out = []
    for x in arms(a):
        for y in arms(b):
            m = meet1(x, y)
            if m is not None and not empty(m) and m not in out:
                out.append(m)
    if not out:
        return {"kind": "bottom"}
    return out[0] if len(out) == 1 else {"kind": "union", "variants": out}


def meet1(x, y):
    if empty(x) or empty(y):
        return None
    if top(x):
        return y
    if top(y):
        return x
    kx, ky = x.get("kind"), y.get("kind")
    if kx == "rec" or ky == "rec":
        raise KeyError("unresolved reference")
    scalars = {"nil", "str", "sym", "bool", "int", "float", "date", "time"}
    containers = {"array", "tuple", "hash", "record", "fn"}
    if kx != ky:
        if kx in scalars and ky in scalars or kx in scalars and ky in containers or ky in scalars and kx in containers:
            return None
        raise KeyError("intersection unavailable: %s / %s" % (kx, ky))
    if kx in ("nil", "str", "sym", "bool", "int", "float", "date", "time", "self_instance"):
        return x
    if kx == "array":
        return {"kind": "array", "elem": meet(x["elem"], y["elem"])}
    if kx == "hash":
        return {"kind": "hash", "key": meet(x["key"], y["key"]), "value": meet(x["value"], y["value"])}
    if kx == "tuple":
        if len(x["elems"]) != len(y["elems"]):
            return None
        elems = [meet(a, b) for a, b in zip(x["elems"], y["elems"])]
        return None if any(empty(t) for t in elems) else {"kind": "tuple", "elems": elems}
    if kx == "class" and x.get("id") == y.get("id") and len(x.get("args", [])) == len(y.get("args", [])):
        return dict(x, args=[meet(a, b) for a, b in zip(x.get("args", []), y.get("args", []))])
    if kx == "fn":
        if {k: v for k, v in x.items() if k != "ret"} != {k: v for k, v in y.items() if k != "ret"}:
            raise KeyError("intersection unavailable: function contracts")
        return dict(x, ret=meet(x["ret"], y["ret"]))
    if covers(y, x):
        return x
    if covers(x, y):
        return y
    raise KeyError("intersection unavailable: %s / %s" % (kx, ky))


RUBY_KIND = {"NilClass": ("nil",), "String": ("str",), "Symbol": ("sym",), "TrueClass": ("bool",),
             "FalseClass": ("bool",), "Integer": ("int",), "Float": ("float",), "Array": ("array", "tuple"),
             "Hash": ("hash", "record")}


def admits(t, ruby_class):
    if t is None:
        return False
    if top(t):
        return True
    kinds = RUBY_KIND.get(ruby_class, ())
    for x in arms(t):
        if x.get("kind") == "rec":
            raise KeyError("unresolved reference")
        if x.get("kind") in kinds or (x.get("kind") == "class" and x.get("id") == ruby_class):
            return True
    return False


# ---------------------------------------------------------------- cells, dumps and records

def records(cache, label):
    try:
        return obs.label_records(obs.load_label(cache, label))
    except (OSError, ValueError, KeyError, TypeError, AttributeError):
        return None


def cell(recs, app, setting):
    r = (recs or {}).get(app + "/" + setting)
    if not isinstance(r, dict) or not r.get("valid") or not isinstance(r.get("directory"), str):
        return None
    o = r.get("observations")
    d = o.get("value_digests") if isinstance(o, dict) else None
    return r if isinstance(d, dict) and set(d) == set(TABLES) and all(isinstance(v, str) for v in d.values()) else None


def numeric(x):
    return type(x) is int and x >= 0


def valid_ty(t, nullable=False):
    if t is None:
        return nullable
    if not isinstance(t, dict) or not isinstance(t.get("kind"), str):
        return False
    k = t["kind"]
    fields = {"array": ("elem",), "hash": ("key", "value"), "fn": ("ret",)}
    if k in fields:
        return all(f in t and valid_ty(t[f]) for f in fields[k])
    if k in ("tuple", "union", "class"):
        f = {"tuple": "elems", "union": "variants", "class": "args"}[k]
        return isinstance(t.get(f), list) and all(valid_ty(x) for x in t[f]) and \
            (k != "class" or isinstance(t.get("id"), str))
    if k == "rec":
        return isinstance(t.get("slot"), str)
    if k == "record":
        row = t.get("row")
        return isinstance(row, dict) and isinstance(row.get("fields"), dict) and \
            all(valid_ty(x) for x in row["fields"].values())
    return k in {"nil", "str", "sym", "bool", "int", "float", "date", "time", "self_instance", "untyped",
                 "bottom", "var", "relation"}


def stderr_records(r, tag):
    out = []
    path = Path(r["directory"]) / "stderr.log"
    if not path.exists():
        return None
    try:
        with path.open(errors="replace") as stream:
            for line in stream:
                if line.startswith(tag + ": "):
                    v = json.loads(line[len(tag) + 2:])
                    if not isinstance(v, dict):
                        return None
                    out.append(v)
    except (OSError, ValueError, TypeError):
        return None
    return out


def load_dump(r, keys=None):
    """(fingerprint, {(part, key): canonical type text}, {(part, key): resolved type}); types only for `keys`."""
    path = Path(r["directory"]) / "contributor-values.jsonl"
    if not path.exists():
        return None
    hashes, refs, wanted = {}, {}, {}
    counts = {p: 0 for p in VALUE_PARTS + ("aliases",)}
    aliases = {}
    with path.open() as stream:
        fp = json.loads(next(stream, "null"))
        if not isinstance(fp, dict) or fp.get("part") != "fingerprint":
            raise ValueError("missing fingerprint")
        expected = fp.get("row_counts")
        inventory = fp.get("alias_inventory")
        if not isinstance(expected, dict) or set(expected) != set(counts) or \
                not all(numeric(v) for v in expected.values()) or not isinstance(inventory, dict) or \
                not all(isinstance(k, str) and isinstance(v, str) for k, v in inventory.items()):
            raise ValueError("missing or invalid row/alias inventory")
        complete = None
        for line in stream:
            v = json.loads(line)
            if not isinstance(v, dict) or complete is not None:
                raise ValueError("invalid record or data after completion")
            if v.get("part") == "complete":
                complete = v
                continue
            if v.get("part") not in counts or not isinstance(v.get("key"), str):
                raise ValueError("invalid row identity")
            k = (v["part"], v["key"])
            if k in hashes:
                raise ValueError("duplicate dump row " + repr(k))
            # Compare the probe's `ty` JSON, whose fold references are symbolic slot keys: the native `hash` uses
            # slot numbers, which a different interning order renumbers without changing any value.
            if v["part"] == "aliases":
                if not isinstance(v.get("module"), str):
                    raise ValueError("invalid alias row")
                aliases[v["key"]] = v["module"]
            elif "ty" not in v or not valid_ty(v["ty"], nullable=v["part"] in ("ir", "controller_cache")) or \
                    not isinstance(v.get("hash"), (int, str)):
                raise ValueError("invalid value row")
            counts[v["part"]] += 1
            text = v.get("module") if v["part"] == "aliases" else json.dumps(v.get("ty"), sort_keys=True)
            hashes[k] = hashlib.sha1(str(text).encode()).hexdigest()[:20]
            if v["part"] == "returns":
                refs["return:" + v["key"]] = v.get("ty")
            elif v["part"] == "side_table":
                refs[v["key"]] = v.get("ty")
            if keys is not None and k in keys:
                wanted[k] = v.get("ty")
        if complete is None or complete.get("row_counts") != counts or expected != counts or inventory != aliases:
            raise ValueError("incomplete value or alias dump")

    def resolve(t, seen):
        if isinstance(t, list):
            return [resolve(x, seen) for x in t]
        if not isinstance(t, dict):
            return t
        if t.get("kind") == "rec":
            slot = t.get("slot")
            m = RET_SLOT.fullmatch(slot or "")
            look = slot
            if m:
                c, meth, side = m.groups()
                look = "return:" + json.loads(c) + ("." if side == "true" else "#") + json.loads(meth)
            if look not in refs or slot in seen:
                return t  # left as a reference: covers() reports it unavailable
            return resolve(refs[look], seen | {slot})
        return {k: resolve(v, seen) for k, v in t.items()}

    return fp, hashes, {k: resolve(t, set()) for k, t in wanted.items()}


def dump_valid(r, fp):
    report = Path(r["directory"]) / "report.json"
    if not report.exists():
        return False
    try:
        return fp.get("part") == "fingerprint" and fp.get("digests") == json.loads(report.read_text()).get("digest") \
            == r["observations"]["value_digests"]
    except (OSError, ValueError, TypeError, KeyError):
        return False


def root_class(part, key):
    if part in ("returns", "params", "controller_cache", "aliases"):
        # Class names contain "::" but never "#" or "."; a class-side key is "Class.method".
        return key.split("#", 1)[0] if "#" in key else key.split(".", 1)[0]
    if part == "side_table":
        m = CLASS_IN_KEY.search(key)
        return json.loads(m.group(1)) if m else None
    if part == "ir":
        try:
            node = json.loads(key[:key.rindex("}:occurrence:") + 1])
            src = json.loads(json.loads(node["source"])[0])
            return "view" if src[0] == "view" else src[0]
        except (ValueError, KeyError, IndexError, TypeError):
            return None
    return None


# ---------------------------------------------------------------- checks

def check_pregate(recs_c):
    out = []
    for pair, names in (("v0-a0", V0), ("v1-a1", V1)):
        cells = [cell(recs_c, "campfire", n) for n in names]
        if None in cells:
            out.append(rec("PG-race", "campfire/" + pair, "unavailable", "missing or invalid control cell"))
            continue
        d = [x["observations"]["value_digests"] for x in cells]
        others = all(d[i][t] == d[0][t] for i in range(4) for t in TABLES if t != "returns")
        race = d[2]["returns"] != d[0]["returns"]
        out.append(rec("PG-race", "campfire/" + pair, "pass" if others and race else "fail",
                       {"returns_differs_at_2": race, "other_nine_equal": others}))
    return out


@evidence_guard("P1-parity")
def check_parity(recs_c, recs_s, app, settings, mandatory=True):
    out = []
    for n in settings:
        c, s = cell(recs_c, app, n), cell(recs_s, app, n)
        if c is None or s is None:
            out.append(rec("P1-parity", app + "/" + n, "unavailable", "missing or invalid cell", mandatory))
            continue
        diff, missing = [], []
        for f in PARITY_FIELDS:
            x, y = obs.observed(c, f), obs.observed(s, f)
            if f != "verify" and (x is None or y is None):
                missing.append(f)
            elif x != y:
                diff.append(f)
        status = "fail" if diff else ("unavailable" if missing else "pass")
        out.append(rec("P1-parity", app + "/" + n, status, {"differs": diff, "unavailable": missing}, mandatory))
    return out


@evidence_guard("shipping-defaults")
def check_defaults(directory):
    out = []
    for mode in ("on", "off"):
        d, ref = Path(directory) / mode / "unset", DEFAULTS_RECEIPTS / mode / "unset"
        try:
            code = int((d / "exit").read_text().strip())
            mine, theirs = json.loads((d / "report.json").read_text()), json.loads((ref / "report.json").read_text())
            valid = code in (0, 1) and isinstance(mine.get("digest"), dict) and len(mine["digest"]) == 9 \
                and mine.get("census") is not None
        except (OSError, ValueError):
            out.append(rec("shipping-defaults", mode, "unavailable", "probe receipt missing or unreadable"))
            continue
        if not valid:
            out.append(rec("shipping-defaults", mode, "unavailable", "invalid probe: exit, nine digests or census"))
            continue

        def kinds(path):
            counts = {}
            with path.open(errors="replace") as stream:
                for line in stream:
                    m = DIAG.search(line)
                    if m:
                        k = m["sev"] + "/" + m["kind"]
                        counts[k] = counts.get(k, 0) + 1
            return counts
        diff = [k for k in ("digest", "census", "loops", "verify") if mine.get(k) != theirs.get(k)]
        try:
            if kinds(d / "probe-campfire.stderr") != kinds(ref / "probe-campfire.stderr"):
                diff.append("diagnostic kinds")
        except OSError:
            out.append(rec("shipping-defaults", mode, "unavailable", "probe stderr missing"))
            continue
        out.append(rec("shipping-defaults", mode, "fail" if diff else "pass", {"differs": diff}))
    return out


@evidence_guard("L-native")
def check_native(directory):
    out, d = [], Path(directory)
    log, ex = d / "contributor-join-laws.log", d / "contributor-join-laws.exit"
    lines = [l for l in log.read_text(errors="replace").splitlines() if l.startswith("CONTRIBUTOR-JOIN-LAWS ")] \
        if log.exists() else []
    if len(lines) != 1 or not ex.exists():
        out.append(rec("L-laws", "declared_contributor_join_laws", "unavailable", "expected one CONTRIBUTOR-JOIN-LAWS line and an exit file"))
    else:
        try:
            got = json.loads(lines[0][len("CONTRIBUTOR-JOIN-LAWS "):])
            names = {"comm", "assoc", "idem", "identity", "keeps_unknown", "arrival"}
            if not isinstance(got, dict) or not numeric(got.get("cases")) or \
                    not isinstance(got.get("counts"), dict) or not names <= set(got["counts"]) or \
                    not all(numeric(v) for v in got["counts"].values()):
                raise ValueError("invalid native law record")
            ok = ex.read_text().strip() == "0" and got["cases"] >= 100 and not any(got["counts"].values())
            out.append(rec("L-laws", "declared_contributor_join_laws", "pass" if ok else "fail", got))
        except (OSError, ValueError, TypeError):
            out.append(rec("L-laws", "declared_contributor_join_laws", "unavailable", "unreadable or invalid native law record"))
    log, ex = d / "lib-suite.log", d / "lib-suite.exit"
    if not log.exists() or not ex.exists():
        out.append(rec("L-suite", "cargo test --lib", "unavailable", "missing receipt"))
    else:
        text = log.read_text(errors="replace")
        ok = ex.read_text().strip() == "0" and re.search(r"test result: ok\. \d+ passed; 0 failed", text) is not None
        out.append(rec("L-suite", "cargo test --lib", "pass" if ok else "fail", None))
    return out


def check_schedules(recs_j):
    out = []
    for pair, names in (("v0-a0", V0), ("v1-a1", V1)):
        cells = [cell(recs_j, "campfire", n) for n in names]
        if None in cells:
            out.append(rec("C-schedules", "campfire/" + pair, "unavailable", "missing or invalid join cell"))
            continue
        d = [x["observations"]["value_digests"] for x in cells]
        diff = sorted({t for i in range(4) for t in TABLES if d[i][t] != d[0][t]})
        out.append(rec("C-schedules", "campfire/" + pair, "fail" if diff else "pass", {"differing_tables": diff}))
    return out


def closure_of(r):
    got = stderr_records(r, "rh-contributor-closure") if r else None
    if not got or len(got) != 1:
        return None
    cl = got[0]
    if not all(isinstance(cl.get(k), list) for k in ("targets", "excluded_declared", "modules", "classes")):
        return None
    for k in ("targets", "excluded_declared"):
        if any(not isinstance(t, list) or len(t) != 3 or not all(isinstance(v, str) for v in t) for t in cl[k]):
            return None
        if len({tuple(t) for t in cl[k]}) != len(cl[k]):
            return None
    if any(not isinstance(v, str) for k in ("classes", "modules") for v in cl[k]):
        return None
    return cl


def group_of(setting, settings):
    """The settings of the same verification/audit pair: main's schedule envelope for that setting."""
    pair = setting.split("-", 1)[1]
    return [n for n in settings if n.split("-", 1)[1] == pair]


PART_TABLE = {"returns": "returns", "params": "params", "controller_cache": "controller_cache", "ir": "ir",
              "side_table": "side_table"}


def floor_settings(n, settings, part, recs_c, app):
    """The C settings whose meet is main's floor for one row of `part` at setting `n`, and whether the floor
    gates (mandatory) or only reports. A pair with four schedules is its own envelope. A single-schedule
    cross-check borrows the four v0-a0 schedules only for tables whose digests C shows equal between
    unset-v0-a0 and the cross-check setting; elsewhere it compares with C at that setting and only reports."""
    peers = group_of(n, settings)
    if len(peers) >= 4 or app == "discourse" and peers == DISCOURSE:
        return peers, True
    base, here = cell(recs_c, app, "unset-v0-a0"), cell(recs_c, app, n)
    table = PART_TABLE[part]
    if base is not None and here is not None and \
            base["observations"]["value_digests"][table] == here["observations"]["value_digests"][table]:
        return [n] + [x for x in V0 if x in settings], True
    return [n], False


_HASHES = {}


def dump_hashes(r):
    """(fingerprint, row digests) of one cell's dump, parsed once per run; None when missing or not reproducing."""
    try:
        f = Path(r["directory"]) / "contributor-values.jsonl"
        d = (str(f), f.stat().st_size, f.stat().st_mtime_ns) if f.exists() else (str(f), None, None)
        if d not in _HASHES:
            got = load_dump(r)
            _HASHES[d] = got[:2] if got is not None and dump_valid(r, got[0]) else None
        return _HASHES[d]
    except (OSError, ValueError, KeyError, TypeError):
        return None


def compare_app(recs_c, recs_j, app, settings):
    """Rows of J against main's floor: the meet of C's resolved values over the schedules of the same pair.

    A row of J fails when it excludes a value that C admits on every schedule of the floor's settings (a row C
    lacks on one of them constrains nothing), or when C has a non-side-table row on all of them and J lacks it.
    Outside the closure, a row of J must equal C's value on some schedule of the same pair (K3). Each dump is
    parsed twice per run: once for row digests, once for the resolved types of the rows some setting compares."""
    results, plan = {}, {}
    for n in settings:
        own = group_of(n, settings)
        peers = sorted(set(own) | (set(V0) & set(settings) if len(own) < 4 else set()))
        c, j = cell(recs_c, app, n), cell(recs_j, app, n)
        cs = {p: cell(recs_c, app, p) for p in peers}
        if c is None or j is None or None in cs.values():
            results[n] = (None, "missing or invalid cell")
            continue
        if dump_hashes(j) is None or any(dump_hashes(r) is None for r in cs.values()):
            results[n] = (None, "value dump missing or not reproducing the report digests")
            continue
        jh, ch = dump_hashes(j)[1], dump_hashes(c)[1]
        changed = {k for k in set(jh) | set(ch) if jh.get(k) != ch.get(k) and k[0] in VALUE_PARTS}
        plan[n] = (j, cs, changed)
    wanted = {}
    for n, (j, cs, changed) in plan.items():
        for r in [j] + list(cs.values()):
            wanted.setdefault(r["directory"], (r, set()))[1].update(changed)
    types = {}
    for d, (r, keys) in wanted.items():
        try:
            types[d] = load_dump(r, keys)[2]
        except (OSError, ValueError, KeyError, TypeError):
            types[d] = None
    for n, (j, cs, changed) in plan.items():
        if any(types[r["directory"]] is None for r in [j] + list(cs.values())):
            results[n] = (None, "unreadable value dump")
            continue
        c = cs[n]
        jh, ch = dump_hashes(j)[1], dump_hashes(c)[1]
        alias_delta = sorted(str(k) for k in set(jh) | set(ch) if k[0] == "aliases" and jh.get(k) != ch.get(k))
        jt_all, ct_all = types[j["directory"]], {p: types[r["directory"]] for p, r in cs.items()}
        cl = closure_of(j)
        classes = set(cl["classes"]) | {"view"} if cl else None
        out = {"rows": len(changed), "relation": {}, "below_floor": [], "missing_in_join": [], "unresolved": 0,
               "alias_delta": alias_delta, "outside_closure_changed": [], "unattributed": 0,
               "closure": classes is not None, "report_only_below": []}
        for k in sorted(changed):
            jt = jt_all.get(k)
            fl, gating = floor_settings(n, settings, k[0], recs_c, app)
            peer_types = [ct_all[p].get(k) for p in fl]
            try:
                rel = relation(ct_all[n].get(k), jt)
                out["relation"][rel] = out["relation"].get(rel, 0) + 1
                if None not in peer_types:
                    floor = peer_types[0]
                    for t in peer_types[1:]:
                        floor = meet(floor, t)
                    sink = out["below_floor"] if gating else out["report_only_below"]
                    if jt is None:
                        if k[0] != "side_table":
                            (out["missing_in_join"] if gating else out["report_only_below"]).append(
                                {"part": k[0], "key": k[1], "missing_in_join": True})
                    elif not covers(jt, floor) and not var_only_loss(floor, jt):
                        sink.append({"part": k[0], "key": k[1], "floor": floor, "join": jt})
            except KeyError:
                out["unresolved"] += 1
                continue
            if classes is not None:
                rc = root_class(*k)
                if rc is None:
                    out["unattributed"] += 1
                elif rc not in classes and jt not in [ct_all[p].get(k) for p in group_of(n, settings)]:
                    out["outside_closure_changed"].append({"part": k[0], "key": k[1], "relation": rel})
        results[n] = (out, None)
    return results


def check_floor_and_scope(recs_c, recs_j, app, settings, scope_mandatory):
    """K1 (no row below main's floor), K3 (outside-closure rows are values main produced), K4 (aliases)."""
    out, reports = [], []
    for n, (cmp, why) in compare_app(recs_c, recs_j, app, settings).items():
        sc = app + "/" + n
        if cmp is None:
            for name in ("K1-floor", "K3-scope", "K4-aliases"):
                out.append(rec(name, sc, "unavailable", why, scope_mandatory if name == "K3-scope" else True))
            continue
        bad = cmp["below_floor"] + cmp["missing_in_join"]
        k1 = "fail" if bad else ("unavailable" if cmp["unresolved"] else "pass")
        out.append(rec("K1-floor", sc, k1, {"below_floor_or_missing": bad, "count": len(bad),
                                            "unresolved_rows": cmp["unresolved"], "relations": cmp["relation"]}))
        if cmp["report_only_below"]:
            out.append(rec("K1-no-envelope", sc, "report", {"rows": cmp["report_only_below"],
                                                            "count": len(cmp["report_only_below"])}, False))
        if not cmp["closure"]:
            out.append(rec("K3-scope", sc, "unavailable", "rh-contributor-closure record missing", scope_mandatory))
        else:
            k3 = "fail" if cmp["outside_closure_changed"] else ("unavailable" if cmp["unattributed"] else "pass")
            out.append(rec("K3-scope", sc, k3, {"outside_changed": cmp["outside_closure_changed"],
                                                "count": len(cmp["outside_closure_changed"]),
                                                "unattributed": cmp["unattributed"]}, scope_mandatory))
        out.append(rec("K4-aliases", sc, "fail" if cmp["alias_delta"] else "pass",
                       {"count": len(cmp["alias_delta"]), "rows": cmp["alias_delta"][:50]}))
        reports.append({"scope": sc, "changed_rows": cmp["rows"], "relations_vs_same_setting": cmp["relation"]})
    return out, reports


def check_replay(recs_c, recs_j, app, settings):
    """K2: one cell record per declared target, the stored value is the declared join, and the join is
    order-free on the actual values; the closure record is identical in both arms."""
    out = []
    for n in settings:
        c, j = cell(recs_c, app, n), cell(recs_j, app, n)
        sc = app + "/" + n
        if j is None:
            out.append(rec("K2-replay", sc, "unavailable", "missing or invalid join cell"))
            continue
        cl, cl_c = closure_of(j), closure_of(c) if c else None
        cells = stderr_records(j, "rh-contributor-cell")
        summ = stderr_records(j, "rh-contributor-summary")
        if cl is None or cells is None or not summ or len(summ) != 1:
            out.append(rec("K2-replay", sc, "unavailable", "closure, cell or summary records missing"))
            continue
        targets = {"%s#%s" % (t[0], t[1]) for t in cl["targets"]}
        problems, missing = [], []
        seen = [x.get("target") for x in cells if x.get("phase") == "prefinal" and isinstance(x.get("target"), str)]
        if len(seen) != len(set(seen)) or any(t not in targets for t in seen):
            problems.append("duplicate or undeclared cell target")
        if set(seen) != targets:
            missing.append("cell records do not cover all declared targets")
        replay_bad, perm_bad, own_count, module_count = 0, 0, 0, 0
        for x in cells:
            target = x.get("target") if isinstance(x.get("target"), str) else "<missing>"
            if x.get("phase") != "prefinal" or not isinstance(target, str):
                missing.append("invalid cell phase/target")
            for field in ("replay_equal", "perm_equal", "reference_mode"):
                if type(x.get(field)) is not bool:
                    missing.append(target + ": " + field)
            replay_bad += x.get("replay_equal") is False
            perm_bad += x.get("perm_equal") is False
            if x.get("replay_equal") is False or x.get("perm_equal") is False:
                problems.append("replay or permutation failure at " + target)
            hs = [x.get(k) for k in ("stored_hash", "aggregate_hash")]
            if not all((type(h) is int and h >= 0) or (isinstance(h, str) and h) for h in hs):
                missing.append(target + ": required hashes")
            elif hs[0] != hs[1]:
                problems.append("stored and aggregate hashes differ at " + target)
            if "own" not in x or not valid_ty(x.get("own"), nullable=True):
                missing.append(target + ": own type")
            own_count += x.get("own") is not None
            modules = x.get("module_cells")
            if not isinstance(modules, dict) or any(not isinstance(k, str) or not valid_ty(v)
                                                   for k, v in modules.items()):
                missing.append(target + ": module types")
            else:
                module_count += len(modules)
            for field in ("aggregate", "stored"):
                if not valid_ty(x.get(field)):
                    missing.append(target + ": " + field)
            if valid_ty(x.get("aggregate")) and valid_ty(x.get("stored")) and \
                    x["aggregate"] != x["stored"] and x.get("replay_equal") is True:
                problems.append("replay_equal contradicts types at " + target)
        s = summ[0]
        expected = {"targets": len(targets), "own_present": own_count, "module_present": module_count,
                    "replay_failures": replay_bad, "perm_failures": perm_bad}
        for k, v in expected.items():
            if not numeric(s.get(k)):
                missing.append("summary " + k)
            elif s[k] != v:
                problems.append("summary " + k + " does not reconcile")
        if cl_c is not None and cl_c != cl:
            problems.append("closure records differ between arms")
        if c is None or cl_c is None:
            missing.append("control closure")
        status = "fail" if problems else ("unavailable" if missing else "pass")
        out.append(rec("K2-replay", sc, status, {"problems": problems, "unavailable": missing,
                                                "targets": len(targets)}))
    return out


def report_json(r):
    try:
        p = Path(r["directory"]) / "report.json"
        got = json.loads(p.read_text())
        return got if isinstance(got, dict) else None
    except (OSError, ValueError, KeyError, TypeError):
        return None


def counters(report):
    try:
        w = report["worklist"]
        w = w.get("engine", w)
        f = report["fold"]["expansion"]
        out = {"cap_hits": w["cap_hits"], "budget_exhausted": w["budget_exhausted"],
               "fold_budget_cuts": f["budget_cuts"]}
        return out if all(numeric(v) for v in out.values()) else None
    except (KeyError, TypeError, AttributeError):
        return None


def check_invariants(recs_c, recs_j, app, settings):
    """K5. Missing numeric or scheduled loop/table observations are unavailable, never zero."""
    out = []
    for n in settings:
        c, j = cell(recs_c, app, n), cell(recs_j, app, n)
        sc = app + "/" + n
        if c is None or j is None:
            out.append(rec("K5-invariants", sc, "unavailable", "missing or invalid cell"))
            continue
        problems, missing = [], []
        lc, lj = c["observations"].get("loops"), j["observations"].get("loops")
        required_loops = {"production", "views_and_tests", "absorb"}
        def valid_loops(x):
            return isinstance(x, dict) and set(x) == required_loops and all(
                isinstance(v, dict) and v.get("end") in ("settled", "not_run", "ran_to_cap") and
                (v["end"] != "settled" or numeric(v.get("round"))) for v in x.values())
        if not valid_loops(lc) or not valid_loops(lj):
            missing.append("scheduled loops")
        else:
            for k, v in lc.items():
                if v["end"] == "settled" and lj[k]["end"] != "settled":
                    problems.append("loop " + k + " not settled")
        vc, vj = c["observations"].get("verify"), j["observations"].get("verify")
        if "-v1-" in n:
            def movements(xs, loops):
                if not isinstance(xs, list) or not valid_loops(loops):
                    return None
                expected = {k for k, v in loops.items() if v["end"] != "not_run"}
                found, result = set(), {}
                for x in xs:
                    if not isinstance(x, dict) or x.get("loop") not in expected or x["loop"] in found:
                        return None
                    found.add(x["loop"])
                    m = x.get("moved")
                    if not isinstance(m, dict) or not set(TABLES) <= set(m) or not all(numeric(v) for v in m.values()):
                        return None
                    result.update({(x["loop"], k): v for k, v in m.items()})
                return result if found == expected else None
            mc, mj = movements(vc, lc), movements(vj, lj)
            if mc is None or mj is None or set(mc) != set(mj):
                missing.append("scheduled loop/table verify records")
            if mc is not None and mj is not None:
                over = sorted("%s/%s" % k for k in set(mc) & set(mj) if mj[k] > mc[k])
                if over:
                    problems.append("verify movement above control: " + ", ".join(over))
        elif vc is not None or vj is not None:
            problems.append("verify present with verification off")
        a, b = counters(report_json(j)), counters(report_json(c))
        if a is None or b is None:
            missing.append("worklist/fold numeric counters")
        else:
            problems += [k + " above control" for k in a if a[k] > b[k]]
        def pending(x):
            census = x["observations"].get("reason_census")
            provenance = census.get("untyped_by_provenance") if isinstance(census, dict) else None
            return provenance.get("pending") if isinstance(provenance, dict) else None
        pend = [pending(x) for x in (j, c)]
        if not all(numeric(v) for v in pend):
            missing.append("pending census")
        elif pend[0] > pend[1]:
            problems.append("pending census above control")
        dc, dj = c["observations"].get("diagnostics"), j["observations"].get("diagnostics")
        if not all(isinstance(x, dict) and all(isinstance(k, str) and numeric(v) for k, v in x.items())
                   for x in (dc, dj)):
            missing.append("diagnostic counts")
        else:
            problems += [k + " above control" for k in dj if k.startswith("error/") and dj[k] > dc.get(k, 0)]
        status = "fail" if problems else ("unavailable" if missing else "pass")
        out.append(rec("K5-invariants", sc, status, {"problems": problems, "unavailable": missing}))
    return out


def check_witnesses(recs_c, recs_j, app, settings, wmap):
    """W: every CRuby witness the control admits at a returns row, the join admits too."""
    out = []
    entries = [w for w in wmap["witnesses"] if w["app"] == app]
    if not entries:
        return out
    for n in settings:
        c, j = cell(recs_c, app, n), cell(recs_j, app, n)
        sc = app + "/" + n
        if c is None or j is None:
            out.append(rec("W-witness", sc, "unavailable", "missing or invalid cell"))
            continue
        pats = [(w, re.compile(w["key_regex"])) for w in entries]
        try:
            a, b = dump_hashes(c), dump_hashes(j)
            if a is None or b is None:
                raise ValueError("value dump missing or not reproducing the report digests")
            keys = {k for k in set(a[1]) | set(b[1]) if k[0] == "returns" and any(p.fullmatch(k[1]) for _, p in pats)}
            ct, jt = load_dump(c, keys)[2], load_dump(j, keys)[2]
        except (OSError, ValueError) as error:
            out.append(rec("W-witness", sc, "unavailable", str(error)))
            continue
        fails, unknown, matched, coverage = [], 0, 0, []
        for w, p in pats:
            matches = sorted(k for k in keys if p.fullmatch(k[1]))
            control_matches = [k[1] for k in matches if k in ct]
            # Exact registrations, including explicit alternatives, are enumerable even when absent in both variants.
            pattern = w["key_regex"]
            alternatives = re.fullmatch(r"\(([A-Za-z0-9_:|]+)\)#([A-Za-z0-9_?\\]+)", pattern)
            if alternatives:
                owners, name = alternatives.groups()
                expected_targets = [owner + "#" + name.replace(r"\?", "?") for owner in owners.split("|")]
            elif re.fullmatch(r"[A-Za-z0-9_:]+#[A-Za-z0-9_?\\]+", pattern):
                expected_targets = [pattern.replace(r"\?", "?")]
            else:
                expected_targets = control_matches
            missing_targets = sorted(set(expected_targets) - set(control_matches))
            coverage.append({"witness": w["label"], "control_targets": control_matches,
                             "missing_targets": missing_targets,
                             "available": bool(control_matches) and not missing_targets})
            if not control_matches or missing_targets:
                unknown += 1
            for k in matches:
                matched += 1
                try:
                    if k not in ct:
                        unknown += 1
                    elif admits(ct[k], w["ruby_class"]) and (k not in jt or not admits(jt[k], w["ruby_class"])):
                        fails.append({"witness": w["label"], "key": k[1], "join": jt.get(k)})
                except KeyError:
                    unknown += 1
        if matched == 0:
            out.append(rec("W-witness", sc, "unavailable", "no witnessed returns row found"))
            continue
        status = "fail" if fails else ("unavailable" if unknown else "pass")
        out.append(rec("W-witness", sc, status, {"failures": fails, "rows": matched, "unknown": unknown, "coverage": coverage}))
    return out


@evidence_guard("R-precision", report=True)
def report_precision(recs_c, recs_j, recs_a, app, settings):
    rows = []
    for n in settings:
        c, j, a = cell(recs_c, app, n), cell(recs_j, app, n), cell(recs_a, app, n)

        def ua(x):
            return ((x or {}).get("observations", {}).get("reason_census") or {}).get("untyped_anywhere")
        changed = sorted(t for t in TABLES if c and j and
                         c["observations"]["value_digests"][t] != j["observations"]["value_digests"][t])
        dc = (c or {}).get("observations", {}).get("diagnostics") or {}
        dj = (j or {}).get("observations", {}).get("diagnostics") or {}
        delta = {k: dj.get(k, 0) - dc.get(k, 0) for k in set(dc) | set(dj) if dj.get(k, 0) != dc.get(k, 0)}
        rows.append({"scope": app + "/" + n, "untyped_anywhere": {"control": ua(c), "join": ua(j), "arm_A": ua(a)},
                     "tables_changed_vs_control": changed, "diagnostic_deltas": delta,
                     "loops": {"control": (c or {}).get("observations", {}).get("loops"),
                               "join": (j or {}).get("observations", {}).get("loops")}})
    return rec("R-precision", app, "report", rows, False)


@evidence_guard("R-schedule-cells", report=True)
def report_schedule_cells(recs_j, app):
    """Report: declared targets whose cells differ across the four v0-a0 schedules (stratum-1, not ownership)."""
    per = {}
    for n in (CAMPFIRE if app == "campfire" else V0):
        j = cell(recs_j, app, n)
        for x in (stderr_records(j, "rh-contributor-cell") or []) if j else []:
            per.setdefault(x["target"], {})[n] = (json.dumps(x.get("own"), sort_keys=True),
                                                  json.dumps(x.get("module_cells"), sort_keys=True))
    diff = sorted(t for t, v in per.items() if any(len({value for n, value in v.items() if n in group}) > 1 for group in (V0, V1)))
    return rec("R-schedule-cells", app, "report", {"targets_with_schedule_dependent_cells": diff,
                       "settings": CAMPFIRE if app == "campfire" else V0}, False)


# ---------------------------------------------------------------- decisions

def decide(checks, pregate=None):
    mand = [c for c in checks if c["mandatory"]]
    if any(c["status"] == "fail" for c in mand):
        return "KILLED"
    if pregate is not None and any(c["status"] != "pass" for c in pregate):
        return "INCONCLUSIVE (pre-gate)"
    if any(c["status"] == "unavailable" for c in mand):
        return "INCONCLUSIVE"
    return "CONFIRMED"


def labels_from(args):
    labels = {"C": "contributor-join-control", "J": "contributor-join-join", "S": "s1b-spine-ownership-off", "A": "s1b-spine-ownership-on"}
    labels.update(dict(x.split("=", 1) for x in args.label))
    return labels


def load_all(args):
    cache, labels = args.cache_root.resolve(), labels_from(args)
    return {arm: records(cache, labels[arm]) for arm in labels}, labels


def mode_pregate(args):
    recs, _ = load_all(args)
    checks = check_pregate(recs["C"])
    return {"verdict": "PRE-GATE PASS" if all(c["status"] == "pass" for c in checks) else "PRE-GATE FAIL",
            "checks": checks}


def mode_campfire(args):
    recs, labels = load_all(args)
    kit = getattr(args, "kit", False)
    settings = V0 if kit else CAMPFIRE
    pre = [c for c in check_pregate(recs["C"]) if not kit or c["scope"].endswith("v0-a0")]
    checks = [] if kit else check_parity(recs["C"], recs["S"], "campfire", CAMPFIRE)
    if not kit:
        checks += check_defaults(args.defaults) + check_native(args.native)
    checks += [c for c in check_schedules(recs["J"]) if not kit or c["scope"].endswith("v0-a0")]
    k, reports = check_floor_and_scope(recs["C"], recs["J"], "campfire", settings, True)
    checks += k + check_replay(recs["C"], recs["J"], "campfire", settings)
    checks += check_invariants(recs["C"], recs["J"], "campfire", settings)
    report = [report_precision(recs["C"], recs["J"], recs["A"], "campfire", settings),
              report_schedule_cells(recs["J"], "campfire"), rec("R-rows", "campfire", "report", reports, False)]
    verdict = decide(checks, pre)
    return {"hypothesis": "H1", "verdict": ("KIT (v0-a0 subset, not a card verdict): " + verdict) if kit else verdict,
            "labels": labels, "pregate": pre, "checks": checks, "reports": report}


def mode_general(args):
    recs, labels = load_all(args)
    wmap = json.loads((HERE / "witness-map.json").read_text())
    checks, report = [], []
    for app in ("forem", "chatwoot", "mastodon"):
        checks += check_parity(recs["C"], recs["S"], app, FIVE, mandatory=app != "mastodon")
        k, rows = check_floor_and_scope(recs["C"], recs["J"], app, FIVE, False)
        checks += k + check_replay(recs["C"], recs["J"], app, FIVE)
        checks += check_invariants(recs["C"], recs["J"], app, FIVE)
        checks += check_witnesses(recs["C"], recs["J"], app, FIVE, wmap)
        report += [report_precision(recs["C"], recs["J"], recs["A"], app, FIVE), report_schedule_cells(recs["J"], app),
                   rec("R-rows", app, "report", rows, False)]
    return {"hypothesis": "H2", "verdict": decide(checks), "labels": labels, "checks": checks, "reports": report}


def mode_discourse(args):
    recs, labels = load_all(args)
    checks = check_parity(recs["C"], recs["S"], "discourse", DISCOURSE, mandatory=False)
    k, rows = check_floor_and_scope(recs["C"], recs["J"], "discourse", DISCOURSE, False)
    checks += k + check_replay(recs["C"], recs["J"], "discourse", DISCOURSE)
    checks += check_invariants(recs["C"], recs["J"], "discourse", DISCOURSE)
    report = [report_precision(recs["C"], recs["J"], recs["A"], "discourse", DISCOURSE),
              rec("R-rows", "discourse", "report", rows, False)]
    return {"hypothesis": "H3", "verdict": decide(checks), "labels": labels, "checks": checks, "reports": report}


def rollup(h1, h2=None, h3=None):
    if h1 != "CONFIRMED":
        card, h2 = h1, "NOT RUN"
    elif h2 is None:
        card = "INCONCLUSIVE"
    elif h2 == "KILLED":
        card = "KILLED"
    elif h2 == "CONFIRMED":
        card = "CONFIRMED"
    else:
        card = "INCONCLUSIVE"
    return {"card": card, "H1": h1, "H2": h2 or "NOT RUN", "H3 (reported, outside the roll-up)": h3 or "NOT RUN"}


def mode_rollup(args):
    def verdict(p):
        return json.loads(Path(p).read_text())["verdict"] if p else None
    result = rollup(verdict(args.campfire), verdict(args.general), verdict(args.discourse))
    result["verdict"] = result["card"]
    return result


def main(argv=None):
    global VAR_TOP
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("mode", choices=("pregate", "campfire", "general", "discourse", "rollup"))
    p.add_argument("--cache-root", type=Path, default=F / "phase2/observers/cache")
    p.add_argument("--label", action="append", default=[], help="ARM=LABEL override")
    p.add_argument("--native", type=Path, help="directory with contributor-join-laws.{log,exit} and lib-suite.{log,exit}")
    p.add_argument("--defaults", type=Path, help="directory with {on,off}/unset/{report.json,probe-campfire.stderr,exit}")
    p.add_argument("--campfire", type=Path)
    p.add_argument("--general", type=Path)
    p.add_argument("--discourse", type=Path)
    p.add_argument("--var-pending", action="store_true", help="sensitivity reading: a raw Var admits nothing")
    p.add_argument("--kit", action="store_true", help="campfire only: the v0-a0 subset, no parity probes or laws")
    p.add_argument("--out", type=Path)
    args = p.parse_args(argv)
    VAR_TOP = not args.var_pending
    if args.mode == "campfire" and not args.kit and (args.native is None or args.defaults is None):
        p.error("campfire needs --native and --defaults (or --kit for the v0-a0 subset)")
    if args.mode == "rollup" and args.campfire is None:
        p.error("rollup needs --campfire")
    fn = {"pregate": mode_pregate, "campfire": mode_campfire, "general": mode_general,
          "discourse": mode_discourse, "rollup": mode_rollup}[args.mode]
    result = fn(args)
    result["condition"] = "declared-contributor-join-20261015-ea3ec744"
    text = json.dumps(result, indent=1, sort_keys=True, default=str)
    if args.out:
        args.out.write_text(text + "\n")
    print(result["verdict"])
    for c in result.get("checks", []):
        if c["status"] != "pass":
            print("  %s %s %s%s" % (c["status"].upper(), c["check"], c["scope"], "" if c["mandatory"] else " (report)"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
